import logo from './logo.svg';
import './App.css';
import 'bootstrap/dist/css/bootstrap.css';
import React from "react";
import Header from './components/Header.js';
import Menu from './components/Menu.js';
import Footer from './components/Footer.js';




class App extends React.Component{
  render() {
    return (
        <div>
          <Header />
          <Menu />
          <Footer />
        </div>
    );
  }
}

export default App;
