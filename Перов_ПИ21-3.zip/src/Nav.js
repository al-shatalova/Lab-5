import React from "react";
import 'bootstrap/dist/css/bootstrap.css';
import App from "./App";

class Nav extends React.Component {

    render() {
        return(
            <nav className="py-2 bg-body-tertiary border-bottom text-bg-dark">
                <div className="container d-flex flex-wrap ">
                    <ul className="nav me-auto">
                        <li className="nav-item">
                            <a
                                href="#"
                                className="nav-link link-body-emphasis px-2 active"
                                aria-current="page"
                            >
                                Главная
                            </a>
                        </li>
                        <li className="nav-item">
                            <a href="#" className="nav-link link-body-emphasis px-2">
                                Жанры
                            </a>
                        </li>
                        <li className="nav-item">
                            <a href="#" className="nav-link link-body-emphasis px-2">
                                Акции
                            </a>
                        </li>
                        <li className="nav-item">
                            <a href="#" className="nav-link link-body-emphasis px-2">
                                Новинки
                            </a>
                        </li>
                        <li className="nav-item">
                            <a href="#" className="nav-link link-body-emphasis px-2">
                                О нас
                            </a>
                        </li>
                    </ul>
                    <ul className="nav">
                        <li className="nav-item">
                            <a href="#" className="nav-link link-body-emphasis px-2">
                                Войти
                            </a>
                        </li>
                        <li className="nav-item">
                            <a href="#" className="nav-link link-body-emphasis px-2">
                                Зарегистрироваться
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>
        );
    }
}

export default Nav;