import 'bootstrap/dist/css/bootstrap.css';
import React from "react";
import MenuItem from "./MenuItem";

const h1 = 250;
const w1 = 300;
let menuItems = []
menuItems.push({name: 'Креветки с гуакомоле',
    price: '740',
    desc: 'Креветки в легкой панировке обжариваем с небольшим количеством чесночного и сливочного масла.' +
        ' Подаем с гуакомоле. Поливаем оливковым маслом и украшаем свежим базиликом',
    image: 'images/1.jpg',
    weight : '60',
    height: h1, width: w1})
menuItems.push({name: 'Осьминог с печеным картофелем и соусом из паприки',
    price: '1 280',
    desc: 'Осьминога отвариваем в овощном бульоне. Перед подачей обжариваем и подаем' +
        ' с запеченным картофелем с добавлением ароматных трав.  Сервируем мариннованным' +
        ' болгарским перцем  и подаем с соусом рамеско (соус на основе болгарского перца)',
    image: 'images/2.jpg',
    weight : '285',
    height: h1, width: w1})
menuItems.push({name: 'Филе-миньон (прайм)',
    price: '4 050',
    desc: 'Отрез тонкой части говяжьей вырезки, подаем с халапеньо с соленными огурцами',
    image: 'images/3.jpeg',
    weight : '300',
    height: h1, width: w1})
menuItems.push({name: 'Краб, авокадо и чили соус',
    price: '790',
    desc: 'На хрустящий, поджаренный на гриле тост из пшеничного хлеба выкладываем нарезанный' +
        ' кубиками авокадо и мясо краба, заправленные соусом “Руй”. Перед подачей украшаем луком' +
        ' сибулет и поливаем трюфельным маслом',
    image: 'images/4.jpg',
    weight : '180',
    height: h1, width: w1})
menuItems.push({name: 'Крудо из гребешка, тунца и лосося с лимоном',
    price: '1 860',
    desc: 'Крудо из даров Атлантики и северных морей, сочетающее в себе филе тунца ,' +
        ' лосося, гребешок и аргентинскую креветку, заправленные оливковым маслом,' +
        ' сорта экстра Вирджин наивысшего качества . Подаеться с долькой лимона.',
    image: 'images/5.jpg',
    weight : '250',
    height: h1, width: w1})
menuItems.push({name: 'Стейк рибай (прайм)',
    price: '4 960',
    desc: 'Премиальный отруб говядины, толстый край с 5 по 12 ребро',
    image: 'images/6.jpeg',
    weight : '400',
    height: h1, width: w1})
menuItems.push({name: 'Бургер из мраморной говядины и трюфельным фри',
    price: '720',
    desc: 'Бургер с котлетой из мраморной говядины, подаем с сыром чеддер, томатами,' +
        ' маринованными огурцами, маринованным луком и томатным соусом. Сервируем картофелем фри',
    image: 'images/7.png',
    weight : '650',
    height: h1, width: w1})
menuItems.push({name: 'Тартар из говядины с картофельной лепешкой и красной икрой',
    price: '750',
    desc: 'Нарезаем мелким кубиком свежую говядину и корнишоны. Добавляем кетчуп,' +
        ' дижонскую и зернистую горчицу, оливковое и трюфельное масло, мелко рубленную' +
        ' петрушку и лук шалот, свежий куриный желток, несколько капель тобаско и ворчестера.' +
        ' Сервируем красной икрой, луком сибулет.',
    image: 'images/8.jpg',
    weight : '265',
    height: h1, width: w1})
class Menu extends React.Component {
    render(){
        return(
            <div style={{paddingBottom:100}}>
                <h1 style={{paddingTop:50, textAlign: "center"}}>Хиты</h1>
                <table className="products my-lg-5">
                    <tbody>
                    <tr>
                        <MenuItem {...menuItems[0]} />
                        <MenuItem {...menuItems[1]} />
                        <MenuItem {...menuItems[2]} />
                        <MenuItem {...menuItems[3]} />
                    </tr>
                    <tr>
                        <MenuItem {...menuItems[4]} />
                        <MenuItem {...menuItems[5]} />
                        <MenuItem {...menuItems[6]} />
                        <MenuItem {...menuItems[7]} />
                    </tr>
                    </tbody>
                </table>
            </div>


        );
    }
}
export default Menu;