import 'bootstrap/dist/css/bootstrap.css';
import React from "react";

class Header extends React.Component {
    render() {
        return (
            <header className="p-3 text-bg-dark">
                <div className="container">
                    <div className="d-flex flex-wrap align-items-center justify-content-center ">
                        <h2 style={{paddingRight: 150}}>BestRest</h2>
                        <ul className="nav col-12 col-lg-auto me-lg-auto mb-2 justify-content-center mb-md-0">
                            <li>
                                <a href="#" className="nav-link px-2 text-white">
                                    Меню
                                </a>
                            </li>
                            <li>
                                <a href="#" className="nav-link px-2 text-white">
                                    Доставка
                                </a>
                            </li>
                            <li>
                                <a href="#" className="nav-link px-2 text-white">
                                    Бронь столов
                                </a>
                            </li>
                            <li>
                                <a href="#" className="nav-link px-2 text-white">
                                    Акции
                                </a>
                            </li>
                            <li>
                                <a href="#" className="nav-link px-2 text-white">
                                    Контакты
                                </a>
                            </li>
                        </ul>

                        <div className="text-end">
                            <button type="button" className="btn btn-outline-light me-2">
                                Войти
                            </button>
                            <button type="button" className="btn btn-light">
                                Зарегистрироваться
                            </button>
                        </div>
                    </div>
                </div>

            </header>


        );
    }
}

export default Header;