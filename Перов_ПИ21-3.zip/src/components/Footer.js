import 'bootstrap/dist/css/bootstrap.css';
import React from "react";



class Footer extends React.Component{
    render() {
        return(
            <footer className="row row-cols-1 row-cols-sm-2 row-cols-md-5 py-5  border-top text-bg-dark">
                <div className="col mb-3">
                    <h3
                        className="text-body-primary display-6">
                        BestRest
                    </h3>
                    <p className="text-white-body-secondary ">© 2023</p>
                </div>
                <div className="col mb-3"></div>
                <div className="col mb-3">
                    <h5>Меню</h5>
                    <ul className="nav flex-column ">
                        <li className="nav-item mb-3">
                            <a className="nav-link p-0 text-white">
                                Акции
                            </a>
                        </li>
                        <li className="nav-item mb-2">
                            <a href="#" className="nav-link p-0 text-white">
                                Хиты
                            </a>
                        </li>
                        <li className="nav-item mb-2">
                            <a href="#" className="nav-link p-0 text-white">
                                Скоро
                            </a>
                        </li>
                        <li className="nav-item mb-2">
                            <a href="#" className="nav-link p-0 text-white">
                                Детское меню
                            </a>
                        </li>
                    </ul>
                </div>
                <div className="col mb-3">
                    <h5>О нас</h5>
                    <ul className="nav flex-column">
                        <li className="nav-item mb-2">
                            <a href="#" className="nav-link p-0 text-white">
                                Контакты
                            </a>
                        </li>
                        <li className="nav-item mb-2">
                            <a href="#" className="nav-link p-0 text-white">
                                Адреса ресторанов
                            </a>
                        </li>
                        <li className="nav-item mb-2">
                            <a href="#" className="nav-link p-0 text-white">
                                Поддержка
                            </a>
                        </li>
                        <li className="nav-item mb-2">
                            <a href="#" className="nav-link p-0 text-white">
                                Забронировать столик
                            </a>
                        </li>
                    </ul>
                </div>
                <div className="col mb-3">
                    <h5>Сотрудничество</h5>
                    <ul className="nav flex-column">
                        <li className="nav-item mb-2">
                            <a href="#" className="nav-link p-0 text-white">
                                Вакансии
                            </a>
                        </li>
                        <li className="nav-item mb-2">
                            <a href="#" className="nav-link p-0 text-white">
                                Франшиза
                            </a>
                        </li>
                        <li className="nav-item mb-2">
                            <a href="#" className="nav-link p-0 text-white">
                                Организация праздников
                            </a>
                        </li>
                    </ul>
                </div>
            </footer>
        );
    }
}


export default Footer;