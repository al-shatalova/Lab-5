import 'bootstrap/dist/css/bootstrap.css';
import React from "react";

function MenuItem(props) {
    const [showDetails, setShowDetails] = React.useState(false);

    const toggleDetails = () => {
        setShowDetails(!showDetails);
    };

    return (
        <td className="menu-item">
            <div className="card" style={{ textAlign: "left", height: 700, width: 450 }}>
                <div style={{ textAlign: "center", paddingTop: 45}}>
                    <img
                        src={process.env.PUBLIC_URL + props.image}
                        alt={props.name}
                        height={props.height}
                        width={props.width}
                    />
                </div>

                <div className="card-body">
                    <h2>{props.name}</h2>
                    <h3>{props.price} руб.</h3>

                    <button onClick={toggleDetails} className="btn btn-outline-dark me-5">
                        {showDetails ? 'Скрыть' : 'Подробнее'}
                    </button >
                    {showDetails && (
                        <div style={{ width: 420 }}>
                            <h5>{props.weight} гр.</h5>
                            <p>{props.desc}</p>
                        </div>
                    )}
                </div>
            </div>
        </td>
    );
}

export default MenuItem;