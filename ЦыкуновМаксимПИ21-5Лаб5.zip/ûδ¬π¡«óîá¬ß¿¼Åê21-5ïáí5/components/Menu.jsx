import { useState } from 'react';
import menu from '../menu.js';
import Card from './Card';

export default function Menu() {
  const [buttonText, setButtonText] = useState('Показать ингредиенты');
  const [showIngredients, setShowIngredients] = useState(false);

  function toggleIngredients() {
    if (buttonText == 'Показать ингредиенты') {
      setButtonText('Скрыть ингредиенты');
      setShowIngredients(true);
    } else if (buttonText == 'Скрыть ингредиенты') {
      setButtonText('Показать ингредиенты');
      setShowIngredients(false);
    }
  }

  return (
    <main>
      <button onClick={toggleIngredients}>{buttonText}</button>
      <div className="container">
        <div className="toggles"></div>
        {menu.map((item) => (
          <Card
            key={item.id}
            photo={item.photo}
            name={item.name}
            ingredients={item.ingredients}
            price={item.price}
            showIngredients={showIngredients}
          />
        ))}
      </div>
    </main>
  );
}
