export default function Header() {
  return (
    <header>
      <div className="container">
        <div className="logo">Ресторан</div>
        <nav>
          <a href="#">Меню</a>
          <a href="#">Адреса</a>
          <a href="#">Отзывы</a>
          <a href="#">Доставка</a>
          <a href="#">О нас</a>
        </nav>
      </div>
    </header>
  )
}