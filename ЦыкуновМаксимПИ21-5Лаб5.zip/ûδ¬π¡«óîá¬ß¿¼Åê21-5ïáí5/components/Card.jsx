export default function Card(props) {
  return (
    <div className="menu-card">
      <img src={props.photo} alt="" />
      <div className="name">{props.name}</div>
      {props.showIngredients && (
        <div className="ingredients">{props.ingredients}</div>
      )}
      <div className="price">{props.price} ₽</div>
    </div>
  );
}
