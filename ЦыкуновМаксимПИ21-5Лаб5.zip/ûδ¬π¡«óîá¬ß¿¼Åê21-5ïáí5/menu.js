export default [
  {
    id: 1,
    photo: 'https://teremok.ru/upload/iblock/41b/bo96l25ep7rs3j5taw082mh2f3lpkxcu/8e732795-ba68-11e8-af7c-001517db825c.png',
    name: 'Сырники',
    ingredients: 'Творог, мука высшего сорта, сахар-песок, манная крупа, ванильный сахар',
    price: 129,
  },
  {
    id: 2,
    photo: 'https://teremok.ru/upload/iblock/500/flf59d20hhelxm7bj0quqxzdnsxnp0tg/8e8ed585-c17b-11e8-af7c-001517db825c.png',
    name: 'Борщ',
    ingredients: 'Свёкла, вода, соль, картофель, вода, курица, сметана',
    price: 159,
  },
  {
    id: 3,
    photo: 'https://teremok.ru/upload/iblock/df1/ihj4wh9kijzkmq90dj6h8vyqve7ards5/0fc9ae09-ba6c-11e8-af7c-001517db825c.png',
    name: 'Гречка',
    ingredients: 'Гречка, масло подсолнечное самого самого высшего сорта',
    price: 99,
  },
  {
    id: 4,
    photo: 'https://teremok.ru/upload/iblock/205/8wop3qssovt3flh853a7elcn2v8ibsvj/a8e23316-e275-11e8-8982-00152a6e74e2.png',
    name: 'Омлет',
    ingredients: 'Яйца, соль, масло подсолнечное, молоко, базелик',
    price: 329,
  },
  {
    id: 5,
    photo: 'https://teremok.ru/upload/iblock/f82/ecnnrtsi1dtz6igl4hyjiot0w0pji1al/d945dfc7-c17b-11e8-af7c-001517db825c.png',
    name: 'Лапша',
    ingredients: 'Курица, лапша, много воды, масло подсолнечное, соль',
    price: 299,
  },
  {
    id: 6,
    photo: 'https://teremok.ru/upload/iblock/04f/t6oo0t2lhaaw2xrvzbkeqpzuaj9i8zyl/02cf0764-ba63-11e8-af7c-001517db825c.png',
    name: 'Блин',
    ingredients: 'Мука пшеничная, соль, масло сливочное, говядина, сыр',
    price: 329,
  },
];
