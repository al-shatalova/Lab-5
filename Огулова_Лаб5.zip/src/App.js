import React, { useState } from 'react';
import './App.css';

function App() {
  const menuItems = [
    {
      id: 1,
      name: 'Медовик',
      price: 250,
      ingredients: 'Мед, мука, яйца, сахар, цедра лимона, сметана',
      image: 'https://mykaleidoscope.ru/uploads/posts/2021-09/1632819031_4-mykaleidoscope-ru-p-medovik-v-korobke-krasivo-foto-6.jpg',
    },
    {
      id: 2,
      name: 'Наполеон',
      price: 225,
      ingredients: 'Маргарин, вода, яйца, мука, масло, ванилин',
      image: 'https://podacha-blud.com/uploads/posts/2022-09/1664515018_37-podacha-blud-com-p-napoleon-tort-podacha-v-restorane-foto-44.jpg',
    },
    {
      id: 3,
      name: 'Тирамису',
      price: 230,
      ingredients: 'Маскарпоне, печенье савоярди, яйца, кофе, алкоголь',
      image: 'https://klike.net/uploads/posts/2023-03/1679375344_3-21.jpg',
    },
    {
      id: 4,
      name: 'Муравейник',
      price: 230,
      ingredients: 'Вареная сгущенка, печенье, сметана, сахар, яйца',
      image: 'https://mykaleidoscope.ru/x/uploads/posts/2023-05/1684981625_mykaleidoscope-ru-p-tort-muraveinik-klassicheskii-instagram-1.jpg',
    },
    {
      id: 5,
      name: 'Красный бархат',
      price: 199,
      ingredients: 'Какао, кефир, мука, сахар, краситель',
      image: 'http://klublady.ru/uploads/posts/2022-02/1644670110_48-klublady-ru-p-tort-chernii-barkhat-foto-51.jpg',
    },
    {
      id: 6,
      name: 'Птичье молоко',
      price: 150,
      ingredients: 'Яйца, шоколад, сахар, мука',
      image: 'https://aroma-avenue.ru/wp-content/uploads/4/1/b/41b2f5aa84cd809f385548b73332d8d5.png',
    },
    {
      id: 7,
      name: 'Прага',
      price: 250,
      ingredients: 'Шоколад, заварной крем, абрикосовый джем',
      image: 'https://o-tendencii.com/uploads/posts/2022-03/1646099641_3-o-tendencii-com-p-tort-praga-klassicheskii-foto-3.jpg',
    },
    {
      id: 8,
      name: 'Чизкейк',
      price: 350,
      ingredients: 'Рикотта, сливки, яйца, сахар',
      image: 'https://podacha-blud.com/uploads/posts/2022-12/1670519153_44-podacha-blud-com-p-tort-chizkeik-foto-kartinki-47.jpg',
    }
  ];

  const [selectedCategory, setSelectedCategory] = useState(null);
  const [showIngredients, setShowIngredients] = useState({});
  const [selectedItemId, setSelectedItemId] = useState(null);

  const toggleIngredients = (itemId) => {
    setShowIngredients((prevState) => ({
      ...prevState,
      [itemId]: !prevState[itemId],
    }));
    setSelectedItemId(itemId);
  };

  return (
      <div className="App">
        <header className="header">
          <h1>Шоколадница</h1>
        </header>

        <div className="content">
          {selectedCategory ? (
              <div>
                <ul className="menu-items">
                  {menuItems
                      .map((item) => (
                          <div
                              key={item.id}
                              className="menu-item"
                          >
                            <img src={item.image} alt={item.name} />
                            <h3>{item.name}</h3>
                            <p>Цена: {item.price} руб.</p>
                            <button onClick={() => toggleIngredients(item.id)}>
                              {showIngredients[item.id] ? 'Скрыть описание' : 'Показать описание'}
                            </button>
                            {showIngredients[item.id] && (
                                <p>Описание: {item.ingredients}</p>
                            )}
                          </div>
                      ))}
                </ul>
              </div>
          ) : (
              <div>
                <h2>Всё меню</h2>
                <ul className="menu-items">
                  {menuItems.map((item) => (
                      <div
                          key={item.id}
                          className="menu-item"
                      >
                        <img src={item.image} alt={item.name} />
                        <h3>{item.name}</h3>
                        <p>Цена: {item.price} руб.</p>
                        <button onClick={() => toggleIngredients(item.id)}>
                          {showIngredients[item.id] ? 'Скрыть состав' : 'Показать состав'}
                        </button>
                        {showIngredients[item.id] && (
                            <p>{item.ingredients}</p>
                        )}
                      </div>
                  ))}
                </ul>
              </div>
          )}
        </div>
      </div>
  );
}

export default App;
