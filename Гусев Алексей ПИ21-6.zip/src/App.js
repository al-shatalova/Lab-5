import logo from './logo.svg';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import React, { useState } from 'react';

function Dish({food, size = 350}) {
  const [isMenuShown, setIsMenuShown] = useState(false);
  const toggleMenu = () => {
      setIsMenuShown(current => !current);
  };

  return (
      <div className="Dish-container">
          <img
              className="Dish"
              src={food.imageId}
              alt={food.name}
              width={size}
              height={size - 60}
          />
          <p className="Dish-name">{food.name}</p>
          <button onClick={toggleMenu}>Подробнее</button>
          {isMenuShown && (
                <div className="additional-menu">
                    <For_recipe recipe={food.recipe} />
                </div>
            )}
        </div>
    );
}
function For_recipe({recipe}) {
    return (
        <div className="For_recipe-menu">
            <p>Рецепт: {recipe}</p>
        </div>
    );
}


function App() {
    return (
          <div>
            <nav className="navbar navbar-expand-lg navbar-light navbar1">
              <button
                className="navbar-toggler"
                type="button"
                data-toggle="collapse"
                data-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent"
                aria-expanded="false"
                aria-label="Toggle navigation"
              >
                <span className="navbar-toggler-icon"></span>
              </button>

              <div className="collapse navbar-collapse" id="navbarSupportedContent">
                <ul className="navbar-nav mr-auto">
                  <li className="nav-item active">
                  </li>
                  <li className="nav-item">
                    <a className="nav-link" href="#">Наш адрес</a>
                  </li>
                  <li className="nav-item">
                    <a className="nav-link" href="#">Отзывы</a>
                  </li>
                </ul>
                <form className="form-inline ml-auto">
                  <input
                    className="form-control mr-sm-2"
                    type="search"
                    placeholder="Поиск"
                    aria-label="Поиск"
                  />
                  <button className="btn btn-outline-success my-2 my-sm-0" type="submit">Найти</button>
                </form>
              </div>
            </nav>


        
            <h1>В гостях у Алексея</h1>
            <div className="Dish-row">
                <Dish
                    food={{
                        name: 'Пельмени',
                        imageId:
                            'https://www.gastronom.ru/binfiles/images/20160506/b27984f0.jpg',
                        recipe: 'пельмени с говядиной, перец, лавровый лист'
                    }}
                />
                <Dish
                    food={{
                        name: 'Яичница',
                        imageId:
                            'https://img1.russianfood.com/dycontent/images_upl/487/big_486973.jpg',
                            recipe: 'Яйца куриные, хлеб'
                    }}
                />
                <Dish
                    food={{
                        name: 'Омлет',
                        imageId:
                            'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRVw9SmRQE9cpF-bApMbylsRqc5A8rmcKlqFA&usqp=CAU',
                            recipe: 'Яйца куриные, сметана, мука, перец'
                    }}
                />
                <Dish
                    food={{
                        name: 'Чай (черный)',
                        imageId:
                            'https://miychay.com/upload/iblock/7c6/7c664063ba5e6215cb3567de3330c187.jpg',
                            recipe: 'Чай'
                    }}
                />
                <Dish
                    food={{
                        name: 'Чай (зеленый)',
                        imageId:
                            'https://ecobar.by/image/cache/blog/greentea-auto_width_1920.jpg',
                            recipe: 'Чай'
                    }}
                />
                <Dish
                    food={{
                        name: 'Болоньезе',
                        imageId:
                            'https://www.ermolino-produkty.ru/recipes/picts/recipes/tnw682-670%D1%85430_makarony-farshem-po-domashnemu_.jpg',
                            recipe: 'Спагетти, фарш, кетчуп, помидоры'
                    }}
                />
            </div>
        </div>
    );
}

export default App;