import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';


function Dish ({ name, price, descr, isShown, handleClick, image }) {
  return (
    <div className="col-md-4 mb-4">
      <div className="card">
        <img
          src={image}
          className="card-img-top"
          alt={name}
          style={{ height: '200px', objectFit: 'cover' }}
        />
        <div className="card-body">
          <h5 className="card-title">{name}</h5>
          <button className="btn btn-success" onClick={handleClick}>
            {isShown ? 'Скрыть' : 'Подробнее'}
          </button>
          {isShown && (
            <div>
              <p>{descr}</p>
              <p>Цена: {price} Р</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};


function Menu({ dishes }) {
  const [shownDish, setShownDish] = useState(-1);

  function handleButton(index) {
    setShownDish((prevIndex) => (prevIndex === index ? -1 : index));
  }

  return (
    <div className="row">
      {dishes.map((dish, index) => (
        <Dish
          key={index}
          name={dish.name}
          price={dish.price}
          descr={dish.descr}
          isShown={shownDish === index}
          handleClick={() => handleButton(index)}
          image={dish.image}
        />
      ))}
    </div>
  );
};

function App() {
  const dishes = [
    {
      name: 'Биг Спешиал Острый Микс',
      price: 516,
      descr: 'Неповторимый сандвич с большим рубленым бифштексом из 100% отборной говядины на большой булочке с кунжутом. Внутри свежие овощи, сыр эмменталь, соус с дымком и специальный пряный соус из микса пикантных перцев.',
      image: '/img1.jpg',
    },
    {
      name: 'Сырные колечки',
      price: 109,
      descr: 'Аппетитные колечки из тянущегося сыра в хрустящей панировке.',
      image: '/img2.jpg',
    },
    {
      name: 'Айс Де Люкс Шоколадно-апельсиновое',
      price: 135,
      descr: 'Мороженое из натурального цельного молока с добавлением апельсинового топпинга и шоколадной крошки.',
      image: '/img3.jpg',
    },
    {
      name: 'Согревающий пунш',
      price: 119,
      descr: 'Горячий напиток, в основе которого натуральное пюре из ягод с добавлением спелого апельсина и бадьяна.',
      image: '/img4.png',
    },
    {
      name: 'Двойной Биг Хит',
      price: 248,
      descr: 'Большой бургер с четырьмя рублеными бифштексами из 100% говядины, маринованными огурчиками, свежим салатом «Айсберг», ломтиком плавленого сыра Чеддер и специальным соусом «Биг Хит» на новой булочке с двумя видами кунжута',
      image: '/img5.jpg',
    },
    {
      name: 'Биг Чикен Бургер',
      price: 272,
      descr: 'Большой бургер с нежным филе куриной грудки в хрустящей панировке, сыром Эмменталь, сочными ломтиками помидора, свежим салатом и специальным соусом на булочке с кунжутом',
      image: '/img6.jpg',
    }
  ];

  return (
    <div>
      <nav className="navbar navbar-expand-lg navbar-dark bg-success">
        <a className="navbar-brand ms-3" href="#">
          Вкусно и весело
        </a>
        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav mr-auto">
            <li className="nav-item">
              <a className="nav-link" href="#">
                Меню
              </a>
            </li>
            <li className="nav-item">
              <a className="nav-link" href="#">
                Акции
              </a>
            </li>
          </ul>
          <ul className="navbar-nav ml-auto">
            <li className="nav-item">
              <a className="nav-link" href="#">
                Кафе
              </a>
            </li>
            <li className="nav-item">
              <a className="nav-link" href="#">
                Кидз Комбо
              </a>
            </li>
            <li className="nav-item">
              <a className="nav-link" href="#">
                Качество
              </a>
            </li>
            <li className="nav-item">
              <a className="nav-link" href="#">
                Мои бонусы
              </a>
            </li>
            <li className="nav-item">
              <a className="nav-link" href="#">
                Новости
              </a>
            </li>
            <li className="nav-item">
              <a className="nav-link" href="#">
                О нас
              </a>
            </li>
          </ul>
        </div>
      </nav>
      <div className="container mt-4">
        <h1 className="mb-4 display-4 text-center">Приходи к нам! Наше меню</h1>
        <Menu dishes={dishes} />
      </div>
    </div>
  );
};

export default App;
