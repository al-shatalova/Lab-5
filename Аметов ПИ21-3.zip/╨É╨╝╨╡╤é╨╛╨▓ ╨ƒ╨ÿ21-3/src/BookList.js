import React from 'react';
import GridItem from './GridItem';
import GridItemSmall from "./GridItemSmall";

function Card({children}) {

  return (
      <div className="row">{children}</div>
  );
}

function BookList() {
  const books = [
    { id:1,title: 'ОСЕННИЙ САЛАТ С ПЕЧЁНОЙ ТЫКВОЙ И СВЁКЛОЙ', price:'410 р.',weight:'210 г.' ,image: 'https://shoko.ru/upload/iblock/1b9/44qwk8mc487pdxi60qiq3dxvyb2ftf43.jpg' },
    { id:2,title: 'САЛАТ ИЗ ПЕЧЁНЫХ БАКЛАЖАНОВ С СОУСОМ ГАМАДАРИ', author: 'Виктор Пелевин',weight:'220 г.' , price:'490 р.', image: 'https://shoko.ru/upload/iblock/d44/u2h5x74nswwyj53kp2zaj9vxzg1f2t2f.jpg' },
    { id:3,title: 'ЧИЗБУРГЕР', author: 'Виктор Пелевин', price:'490 р.',weight:'200 г.' , image: 'https://shoko.ru/upload/iblock/84d/k8nw6y1cf6vqur5eulu7xue1pxageafu.jpg' },
    { id:4,title: 'РОЛЛ С ГОВЯЖЬЕЙ КОЛБАСКОЙ И КАРТОФЕЛЬНЫМ ПЮРЕ', author: 'Виктор Пелевин',weight:'250 г.' , price:'330 р.', image: 'https://shoko.ru/upload/iblock/3bd/tg7z0ttewg76zlr22h1usorotrn5bz0e.jpg' },
    { id:5,title: 'БРУСКЕТТА 4 СЫРА И КОНФИ ИЗ ИНЖИРА', author: 'Виктор Пелевин',weight:'110 г.' , price:'350 р.', image: 'https://shoko.ru/upload/iblock/5cd/eu43j429nchibcsm6w8gp5aotr0r61md.jpg' },
    { id:6,title: 'ЖАРЕНЫЙ СЫР БРИ С КОНФИ ИЗ ИНЖИРА', author: 'Виктор Пелевин',weight:'190 г.' , price:'650 р.', image: 'https://shoko.ru/upload/iblock/282/fyxsnqf23zl40rnksmjw889h7avjsiwl.jpg' },
    { id:7,title: 'СОГРЕВАЮЩИЙ ТОМАТНЫЙ СУП', author: 'Виктор Пелевин',weight:'240 г.' , price:'390 р.', image: 'https://shoko.ru/upload/iblock/804/5zqj7hhi1qjlbtfkg0apo0pociy4pll3.jpg' },
    { id:8,title: 'БЛИННЫЙ ТОРТ', author: 'Виктор Пелевин', price:'290 р.',weight:'160 г.' , image: 'https://shoko.ru/upload/iblock/a97/w3yrj90erusadki8asuprxed5tft808g.jpg' },
  ];

  return (
    <div className="container">
      <Card>
        {books.map((book) => (
          <div className="col-md-3">
            <GridItem {...book} />
            <br></br>
          </div>
        ))}
        </Card>
    </div>
  );
}

export default BookList;