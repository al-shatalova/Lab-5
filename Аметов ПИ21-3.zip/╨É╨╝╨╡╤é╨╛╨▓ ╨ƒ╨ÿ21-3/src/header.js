import React, {useState} from 'react';
import {Button} from "react-bootstrap";
const Header = () => {
    const [isShown, setIsShown] = useState(false);

  const handleClick = () => {
    setIsShown(!isShown);
  };

  return (
      <>
    <div style={{ display: 'flex', alignItems: 'center',  marginLeft:25,}}>
      {isShown && (<button className="btn btn-primary" type="button" data-bs-toggle="offcanvas"
              data-bs-target="#offcanvasWithBothOptions" aria-controls="offcanvasWithBothOptions">АртурРес
      </button>)}
      <div className="form-check form-switch" style={{  marginLeft:25,}}>
        <input className="form-check-input" type="checkbox" role="switch" id="flexSwitchCheckDefault" onClick={handleClick}/>
          <label className="form-check-label" htmlFor="flexSwitchCheckDefault"></label>
      </div>

      <div>
      <div className="offcanvas offcanvas-start" data-bs-scroll="true" tabIndex="-1" id="offcanvasWithBothOptions"
           aria-labelledby="offcanvasWithBothOptionsLabel">
        <div className="offcanvas-header">
          <h5 className="offcanvas-title" id="offcanvasWithBothOptionsLabel">АртурРес</h5>
          <button type="button" className="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div className="offcanvas-body" style={{ display: 'flex', alignItems: 'center', flexDirection: 'column'}}>
          <Button style={{ margin:10, width:200 }}>Завтраки</Button>
          <Button style={{ margin:10, width:200 }}>Обеды</Button>
          <Button style={{ margin:10, width:200 }}>Ужины</Button>
          <Button style={{ margin:10, width:200 }}>Кофе</Button>
          <Button style={{ margin:10, width:200 }}>Чай</Button>
          <Button style={{ margin:10, width:200 }}>Салаты</Button>
          <Button style={{ margin:10, width:200 }}>Десерты</Button>
          <Button style={{ margin:10, width:200 }}>Заказать</Button>
          <Button style={{ margin:10, width:200 }}>Контакты</Button>
        </div>
      </div>
    </div>

    <div style={{ display: 'flex', alignItems: 'center', marginLeft:1000 }}>
      <img style={{ width: 150, height: 100 }} src='https://camo.githubusercontent.com/c704e8013883cc3a04c7657e656fe30be5b188145d759a6aaff441658c5ffae0/68747470733a2f2f6e6573746a732e636f6d2f696d672f6c6f676f5f746578742e737667' />

      <form className="form-inline">
        <input className="form-control" type="text" placeholder="Поиск" aria-label="Search" />
        <button className="btn btn-outline-success" type="submit">Поиск</button>
      </form>
    </div>
      </div>
          </>
  );
}

export default Header;
