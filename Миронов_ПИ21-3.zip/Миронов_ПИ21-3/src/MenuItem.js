import React, { useState } from 'react';

const MenuItem = ({ name, photo, price, contents }) => {
  const [showDetails, setShowDetails] = useState(false);

  const toggleDetails = () => {
    setShowDetails(!showDetails);
  };

  return (
    <div className="card" style={{ display: 'grid', placeItems: 'center' }}>
      <img src={photo} className="card-img-top" alt={name} style={{ width: '822px', height: '411px' }}/>
      <div className="card-body" style={{ display: 'grid', placeItems: 'center' }}>
        <h3 className="card-title" style = {{ fontWeight: "bold" }}>{name}</h3>
        <button className="btn btn-primary" onClick={toggleDetails}>
          {showDetails ? 'Скрыть' : 'Подробнее'}
        </button>
        {showDetails && (
          <div>
            <p className="card-text">Цена: {price}</p>
            <p className="card-text">Описание: {contents}</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default MenuItem;
