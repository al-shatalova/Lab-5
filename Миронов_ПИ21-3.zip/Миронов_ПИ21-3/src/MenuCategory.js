import React from 'react';
import MenuItem from './MenuItem';

const MenuCategory = ({ category, items }) => {
  return (
    <div>
      <h1 style = {{ fontWeight: "bold" }}>{category}</h1>
      {items.map((item, index) => (
        <MenuItem key={index} name={item.name} photo={item.photo} price={item.price} contents={item.contents} />
      ))}
    </div>
  );
};

export default MenuCategory;
