import React from 'react';

const SectionMenu = ({ sections, activeSection, setActiveSection }) => {
  return (
    <div className="list-group">
      {sections.map((section, index) => (
        <a
          key={index}
          href="#"
          className={`list-group-item list-group-item-action ${activeSection === section ? 'active' : ''}`}
          onClick={() => setActiveSection(section)}
        >
          {section}
        </a>
      ))}
    </div>
  );
};

export default SectionMenu;