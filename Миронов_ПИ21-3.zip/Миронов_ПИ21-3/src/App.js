import React, { useState } from 'react';
import MenuCategory from './MenuCategory';
import SectionMenu from './SectionMenu';

const menuData = [
  {
    category: 'Закуски',
    items: [
      {
        name: 'Брускетта',
        photo: '/images/brushetta.jpg',
        price: '400 ₽',
        contents: 'Поджаренный хлеб с помидорами, луком и бальзамическим соусом',
      },
      {
        name: 'Куриные крылья',
        photo: '/images/chicken_wings.jpg',
        price: '750 ₽',
        contents: 'Жареные куриные крылья и сельдереем и сметанным соусом',
      },
    ],
  },
  {
    category: 'Основные блюда',
    items: [
      {
        name: 'Стейк',
        photo: '/images/steak.jpg',
        price: '1250 ₽',
        contents: 'Поджаренный говяжий стейк (прожарка на выбор)',
      },
      {
        name: 'Паста Карбонара',
        photo: '/images/pasta_carbonara.jpg',
        price: '500 ₽',
        contents: 'Спагетти с беконом, яйцами и кремовым соусом',
      },
    ],
  },
];

const App = () => {
  const [activeSection, setActiveSection] = useState('Основные блюда');

  const filteredMenuData = menuData.find((menu) => menu.category === activeSection);

  return (
    <div className="container">
      <div className="row">
        <div className="col-md-3">
          <SectionMenu
            sections={['Основные блюда', 'Закуски']}
            activeSection={activeSection}
            setActiveSection={setActiveSection}
          />
        </div>
        <div className="col-md-9">
          <MenuCategory category={filteredMenuData.category} items={filteredMenuData.items} />
        </div>
      </div>
    </div>
  );
};

export default App;
