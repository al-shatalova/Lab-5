import React from 'react';
import ImgGen from "./ImgGen.jsx";


const Wrapper = ({children}) => {
    return (
        <div className={'list'}>
            {children}
        </div>
        );
};

export default Wrapper;