import React, { useState } from 'react';




const ImgGen = (props) => {
    const [text, setText] = useState('')
    const [ingred, setIngred] = useState('')
    function extern() {
        setText(props.data.description)
        setIngred('Ингредиенты: ' + props.data.ingred)
    }

    return (
        <div className={"product"}>
            <img  src={props.data.imageUrl} alt="" width = {props.size} height={props.size}/>
            <p><strong>{props.data.cost}г</strong></p>
            <p>{text}</p>
            <p>{ingred}</p>

            <button onClick={() => extern()}>Расширить</button>
        </div>
    );
};

export default ImgGen;