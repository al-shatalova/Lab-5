import { useState } from 'react'
import Header  from './components/Header.jsx'
import ImgGen  from './components/ImgGen.jsx'
import Wrapper  from './components/Wrapper.jsx'



function App() {
  const [req, setReq] = useState('');
  
  function Generate(req){
    console.log(req)
    if (req === '') {
      setReq('new')
    }
    else {
      setReq('')
  
    }
  }
  
  
  const data = [
    {key: 1, imageUrl: 'https://e2.edimdoma.ru/data/posts/0002/2608/22608-ed4_wide.jpg?1631188266', description:'рамен', cost: 150, ingred: 'мясо, лапша'},
    {key: 2, imageUrl: 'https://grandkulinar.ru/uploads/posts/2014-07/1405953056_sposoby-oformleniya-blyud.jpg', description: 'рыба',cost: 1200, ingred: 'рыба, лимон'},
    {key: 3, imageUrl: 'https://kremlin-product.ru/upload/iblock/17b/7l4jrjv2yn00aejnjjj4tabm14dw3942/grilled_vegetables.jpg', description: 'овощи', cost: 349, ingred: 'баклажаны, помидоры'},
    {key: 4, imageUrl: 'https://img.freepik.com/free-photo/top-view-tasty-cooked-fish-with-fresh-vegetables-on-a-dark-table_140725-143785.jpg', description: 'рыба', cost: 250, ingred: 'рыба, помидоры'},
    {key: 6, imageUrl: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTyfnu5waksFgzFDEfB6P6iDZUwtWN_-GC-eQ&usqp=CAU', description: 'спагетти', cost: 350, ingred: 'бекон, лук'},
    {key: 7, imageUrl: 'https://kuku.travel/wp-content/uploads/2019/05/%D1%80%D1%83%D0%BB%D1%8C%D0%BA%D0%B0.jpg', description: 'рулька', cost: 320, ingred: 'мясо, чеснок'},
    {key: 8, imageUrl: 'https://cdn.fishki.net/upload/post/201505/21/1539413/50-obyazatelnyh-blyud-1.jpg', description: 'ребра', cost: 150, ingred: 'мясо, салат'},
    {key: 9, imageUrl: 'https://amiel.club/uploads/posts/2022-03/1647707133_2-amiel-club-p-kartinki-blyud-dlya-menyu-2.jpg', description: 'салат', cost: 320, ingred: 'рыба, овощи'},
    {key: 10, imageUrl: 'https://vdvsn.ru/upload/iblock/d3a/d3a98e01363561706fe10fdd4f596058.jpg', description: 'картофель', cost: 399 ,ingred: 'картофель, лук'},
    {key: 11, imageUrl: 'https://img.newgrodno.by/wp-content/uploads/1675952169a9252928b5a06dbfc1cad8d936f90f89.jpeg', description: 'селёдка', cost: 100, ingred: 'рыба, овощи'},
    {key: 12, imageUrl: 'https://hausemafia.ru/thumb/2/AamAL4zfUzvjwTRor5chhg/r/d/29908_large.jpg', description: 'рыба', cost: 500, ingred: 'рыба, лапша'},
  ]

  if (req === 'new'){
    return (
      <>
      <Header req= {req}/>
      <section>
        <h2></h2>
        <Wrapper>
          {data.map((rowData) => (
              <ImgGen data={rowData} key={rowData.id} size={100}/>
          ))}
        </Wrapper>
      </section>
      <button onClick={() => Generate(req)}>Change</button>
      </>
    )
  }
  else {
    return (
      <>
      <Header/>
      <section>
        <h2></h2>
        <Wrapper>
          {data.map((rowData) => (
              <ImgGen data={rowData} key={rowData.id} size={300}/>
          ))}
        </Wrapper>
      </section>
      <button onClick={() => Generate(req)}>Изменить</button>

      </>
    )
  }
}

export default App
