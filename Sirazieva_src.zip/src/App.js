import React, { useState } from 'react';
import './App.css';

const breakfastMenu = [
  { 
    id: 1,
    name: 'Альфредо с курицей',
    description: 'Яйца, сыр, помидоры',
    price: '150р',
    image: 'https://regions.shoko.ru/upload/resize_cache/s1/fit_70_700x700/iblock/f3f/f3f5d59537c96c78cbd3f096413f0bdd.jpg',
  },
  { 
    id: 2,
    name: 'Паровые котлеты',
    description: 'Мука, молоко, сахар',
    price: '120р',
    image: 'https://regions.shoko.ru/upload/resize_cache/s1/fit_70_700x700/iblock/dfd/dfd3083d7af06029f1ce0eec94b665bb.jpg',
  },
  { 
    id: 3,
    name: 'Круассан с ветчиной и сыром',
    description: 'Овсянка, мед, орехи',
    price: '180р',
    image: 'https://regions.shoko.ru/upload/resize_cache/s1/fit_70_700x700/iblock/7e7/7e762e12925278a0c2c303e968037ea4.jpg',
  },
  
];

const lunchMenu = [
  { 
    id: 4,
    name: 'Омлет с томатами, оливками и фетой',
    description: 'Курица, салат, соус',
    price: '250р',
    image: 'https://regions.shoko.ru/upload/resize_cache/s1/fit_70_700x700/iblock/6be/6bec5435ad2621fa16f313a00aefb88b.jpg',
  },
  { 
    id: 5,
    name: 'Паста с овощами',
    description: 'Паста, помидоры, брокколи',
    price: '220р',
    image: 'https://regions.shoko.ru/upload/resize_cache/s1/fit_70_700x700/iblock/eb9/eb9c0e098da7368de32f4fd8d82769c1.jpg',
  },
  { 
    id: 6,
    name: 'Стейк',
    description: 'Говядина, приправы',
    price: '350р',
    image: 'https://regions.shoko.ru/upload/resize_cache/s1/fit_70_700x700/iblock/4ca/4ca059804e49e939409a6c1fa2d9814c.jpg',
  },
];

function App() {
  const [selectedMenu, setSelectedMenu] = useState(breakfastMenu);

  const handleMenuChange = (menuType) => {
    if (menuType === 'breakfast') {
      setSelectedMenu(breakfastMenu);
    } else if (menuType === 'lunch') {
      setSelectedMenu(lunchMenu);
    }
  };

  const [expandedItem, setExpandedItem] = useState(null);

  return (
    <div className="app">
      <div className="top-menu">
        <img src="https://regions.shoko.ru/local/templates/chocolate/images/logo.png"></img>
        <ul>
          <li>Главная</li>
          <li>Меню</li>
          <li>Контакты</li>
        </ul>
      </div>
      <div className="menu-buttons">
        <button onClick={() => handleMenuChange('breakfast')}>Завтраки</button>
        <button onClick={() => handleMenuChange('lunch')}>Обеды</button>
      </div>
      <div className="menu">
        {selectedMenu.map((item) => (
          <div className={`menu-item ${expandedItem === item.id ? 'expanded' : ''}`} key={item.id}>
            <h3>{item.name}</h3>
            <div className="menu-image-container">
              <img src={item.image} alt={item.name} className="menu-image" />
            </div>
            <p>{item.price}</p>
            <button onClick={() => setExpandedItem(item.id)}>Подробнее</button>
            {expandedItem === item.id && (
              <p>Ингредиенты: {item.description}</p>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

export default App;