import React, { useState } from 'react';
import './App.css';


const menuItems = [
  { id: 1, name: 'Пирожное1', image: 'https://condishop.ru/wp-content/uploads/2021/11/72702bf6d6c82fc4739de7e9523985f9-5.jpg', price : ['100р'], ingredients: ['Ингридиенты'] },
  { id: 2, name: 'Пирожное2', image: 'https://main-cdn.sbermegamarket.ru/hlr-system/-63/694/474/911/211/438/100029842335b0.jpg', price : ['100р'], ingredients: ['Ингридиенты'] },
  { id: 3, name: 'Пирожное3', image: 'https://sun9-74.userapi.com/impg/L-uOPJYOcFf3uOAae2bkUqYDoa7z_6zhl2wBtA/RjxAW_4LjuU.jpg?size=604x603&quality=96&sign=e77c3c2a32c168ad5228338e7b91d322&type=album',  price : ['100р'],ingredients: ['Ингридиенты'] },
  { id: 4, name: 'Пирожное4', image: 'https://www.amixon.com/fileadmin/amixon/Articles/0069_Staerke_und_Staerkeaufbereitung/Kuchen.jpg',  price : ['100р'],ingredients: ['Ингридиенты'] },
  { id: 5, name: 'Пирожное5', image: 'https://www.amixon.com/fileadmin/amixon/Articles/0069_Staerke_und_Staerkeaufbereitung/Kuchen.jpg',  price : ['100р'],ingredients: ['Ингридиенты'] },
  { id: 6, name: 'Пирожное6', image: 'https://img.goodfon.ru/original/2048x2048/3/27/vypechka-sladost-keksy-krem.jpg',  price : ['100р'],ingredients: ['Ингридиенты']},
];


function Nav(){
  return(<div>
    <nav class="navbar navbar-expand-lg navbar navbar-dark bg-dark">
      <a class="navbar-brand" href="#">ШОКОЛАДНИЦА</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
    </nav>
  </div>);
}

function App() {
  const [selectedMenuItem, setSelectedMenuItem] = useState(null);

  const handleMenuItemClick = (id) => {
    setSelectedMenuItem(id);
  };

  return (
      <div>
        <Nav/>
        <div className="menu-list">
          {menuItems.map((item) => (
              <div key={item.id} className={`menu-item ${item.id === selectedMenuItem ? 'active' : ''}`}
                   onClick={() => handleMenuItemClick(item.id)}>
                <img src={item.image}/>
                <h3>{item.name}</h3>
                <h5>{item.price}</h5>
                {selectedMenuItem === item.id && (
                    <ul>
                      Состав:
                      {item.ingredients.map((ingredient, index) => (
                          <li key={index}>{ingredient}</li>
                      ))}
                    </ul>
                )}
              </div>
          ))}
        </div>
      </div>
  );
}

export default App;