import React, { useState } from 'react';

const ProductColumn = ({ image, name, price, composition }) => {
    const [showComposition, setShowComposition] = useState(false);

    const toggleComposition = () => {
        setShowComposition(!showComposition);
    };

    return (
        <div style={{
            flex: '0 0 300px',
            margin: '90px',
            padding: '10px',
            border: '1px solid gray',
            background: 'linear-gradient(to right, gray, white, gray)',
            backgroundClip: 'content-box'
        }}>
            <img src={image} alt={name} style={{ width: '300px', height: '250px' }} />
            <div style={{ textAlign: 'center' }}>
                <h3>{name}</h3>
                <h4>{price}</h4>
                <button onClick={toggleComposition}>
                    {showComposition ? 'Скрыть состав' : 'Показать состав'}
                </button>
                {showComposition && <p>{composition}</p>}
            </div>
        </div>
    );
};

const App = () => {
    return (
        <div style={{ display: 'flex' }}>
            <ProductColumn
                image="/images/cakes.jpeg"
                name="Блины с черной экрой"
                price="350₽"
                composition="Яйца, молоко, мука, сахар, соль, растительное масло"
            />
            <ProductColumn
                image="/images/soup.jpeg"
                name="Супчик"
                price="475₽"
                composition="Свекла, капуста, картофель, морковь, лук, чеснок, томатная паста, масло растительное, уксус, сахар, соль, ререц"
            />
            <ProductColumn
                image="/images/chocolate.jpg"
                name="Аленка"
                price="250₽"
                composition="Какао, сахар, орешки, молоко"
            />
        </div>
    );
};

export default App;
