import React, { useState } from 'react';
import { Button, Card } from 'react-bootstrap';

const MenuItem = ({ item }) => {
    const [showDetails, setShowDetails] = useState(false);

    return (
        <Card className="menu-item">
            <Card.Img variant="top" src={process.env.PUBLIC_URL + item.image} style={{ maxWidth: '100%', maxHeight: '200px' }} />
            <Card.Body>
                <Card.Title>{item.name}</Card.Title>
                {showDetails && (
                    <div>
                        <Card.Text>{item.description}</Card.Text>
                        <Card.Text>Цена: {item.price} руб.</Card.Text>
                    </div>
                )}
                <Button
                    onClick={() => setShowDetails(!showDetails)}
                    className={showDetails ? 'btn-hide' : 'btn-show'} // Добавьте классы для цветов
                >
                    {showDetails ? 'Скрыть' : 'Подробнее'}
                </Button>
            </Card.Body>
        </Card>
    );
}

export default MenuItem;
