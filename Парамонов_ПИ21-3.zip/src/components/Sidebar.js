import React from 'react';
import { Nav } from 'react-bootstrap';

const Sidebar = () => {
    return (
        <div className="sidebar">
            <Nav className="flex-column">
                <Nav.Link href="/breakfast">
                    <span style={{ color: 'blue', textDecoration: 'underline' }}>Новинки</span>
                </Nav.Link>
                <Nav.Link href="/lunch">Завтрак</Nav.Link>
                <Nav.Link href="/lunch">Ланч</Nav.Link>
                <Nav.Link href="/dinner">Ужин</Nav.Link>
                <Nav.Link href="/spicy">Острое</Nav.Link>
            </Nav>
        </div>
    );
}

export default Sidebar;
