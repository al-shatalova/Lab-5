import React from 'react';
import MenuItem from './MenuItem';

const Menu = ({ menuData }) => {
    return (
        <div className="menu">
            {menuData.map((item, index) => (
                <MenuItem key={index} item={item} />
            ))}
        </div>
    );
}

export default Menu;
