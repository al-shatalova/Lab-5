import React from 'react';
import { Navbar, Nav, NavDropdown } from 'react-bootstrap';

const Header = () => {
    return (
        <Navbar bg="dark" variant="dark" expand="lg">
            <Navbar.Brand>Рестик КАЙФ</Navbar.Brand>
            <Navbar.Toggle aria-controls="basic-navbar-nav" />
            <Navbar.Collapse id="basic-navbar-nav">
                <Nav className="mr-auto">
                    <Nav.Link href="/menu">Меню</Nav.Link>
                    <Nav.Link href="/about">О нас</Nav.Link>
                    <Nav.Link href="/contact">Контакты</Nav.Link>
                    {/* Добавьте другие пункты меню ресторана здесь */}
                    <NavDropdown title="Дополнительно" id="basic-nav-dropdown">
                        <NavDropdown.Item href="/specials">Специальное предложение</NavDropdown.Item>
                        <NavDropdown.Item href="/specials">Скидки</NavDropdown.Item>
                    </NavDropdown>
                </Nav>
            </Navbar.Collapse>
        </Navbar>
    );
}

export default Header;