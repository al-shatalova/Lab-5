import React from 'react';
import './App.css';
import Header from './components/Header';
import Sidebar from './components/Sidebar';
import MenuItem from './components/MenuItem';




const menuData1 = [
    {
        name: 'Cосисочки с пюрешкой',
        description: 'Ооочеень безумно просто какие вкусные сосисоны с пюрехой',
        price: 350,
        image: '/images/sausages.jpg',
    },
    {
        name: 'Котлетки с пюрешкой',
        description: 'Ооочеень безумно просто какие вкусные котлетосы с пюрехой',
        price: 400,
        image: '/images/cutlet.jpg',
    },
    // Add more menu items with their respective details and images here
];

const menuData2 = [
    {
        name: 'Борщик красный',
        description: 'К борщу — это традиционное украинское и русское блюдо, которое также популярно в других странах СНГ и восточной Европы. Борщ - это суп, который приготавливается из сочетания красной свеклы, мяса (часто свинины или говядины), овощей и специй. Важной частью борща является кислая компонента, как правило, добавляется квасолила (сок из квашеной капусты) или уксус.',
        price: 450,
        image: '/images/borch.jpeg',
    },
    {
        name: 'Спаггети карбонара',
        description: 'Спагетти карбонара - это итальянское блюдо, которое состоит из спагетти, гуанчиале (или панчетты), яиц, сыра Пекорино Романо и специй',
        price: 500,
        image:  '/images/carbonar.jpg',
    },
    // Add more menu items with their respective details and images here
];


const App = () => {
    return (
        <div className="App">
            <Header />
            <div className="container-fluid">
                <div className="row">
                    <div className="col-md-3 col-lg-2 sidebar-container">
                        <Sidebar />
                    </div>
                    <main className="col-md-9 ml-sm-auto col-lg-10 px-4">
                        <div className="row">
                            <div className="col-md-6">
                                {menuData1.map((item, index) => (
                                    <MenuItem key={index} item={item} />
                                ))}
                            </div>
                            <div className="col-md-6">
                                {/* Второй столбик с карточками товаров */}
                                {menuData2.map((item, index) => (
                                    <MenuItem key={index} item={item} />
                                ))}
                            </div>
                        </div>
                    </main>
                </div>
            </div>
        </div>
    );
}

export default App;