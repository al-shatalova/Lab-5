import "./App.css";
import React, { useState } from "react";
import data from "./data.js";
import Avatar from "./Avatar";



export default function App() {
  const [show, setShow] = useState(false);

  function misha() {
    setShow((show) => !show);
  }

  return (
    <div>
      <header>
        <h2>Ресторан "У Миши"</h2>
        <div className="flex-container">
          <h4>Меню</h4>
          <h4>Адреса</h4>
          <h4>Отзывы</h4>
          <h4>Акции</h4>
          <h4>Контакты</h4>
        </div>
      </header>
      <div className="flex-container">
        {data.map((item) => (
          <Avatar
            key={item.id}
            title={item.title}
            imageId={item.imageId}
            description={item.description}
            price={item.price}
            show={show}
          />
        ))}
      </div>
      <center><button onClick={misha}>Описание</button></center>
    
    </div>
  );
}
