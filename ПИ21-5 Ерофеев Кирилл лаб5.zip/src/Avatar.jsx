export default function Avatar(props) {
  return (
    <div>
      <img className="avatar" src={props.imageId} alt={props.title} />
      {props.show && <h5>{props.description}</h5>}
      <h3>{props.price} ₽</h3>
    </div>
  );
}
