export default [
    {
        id: 1,
        title: "Котлеты с картошкой и салатом",
        imageId: "https://mykaleidoscope.ru/x/uploads/posts/2022-09/1663730487_53-mykaleidoscope-ru-p-kartoshka-s-kotletoi-yeda-pinterest-60.jpg",
        description: "Что может быть лучше, чем свиные котлеты с варёной картошкой?",
        price: 1000
      },
      {
        id: 2,
        title: "Сосиски с картошкой и овощами",
        imageId: "https://s1.1zoom.me/b4652/504/The_second_dishes_Vienna_sausage_Potato_Wood_520555_1600x1200.jpg",
        description: "Сосиски из свежайшего мяса, подающиеся с картофелем и овощами",
        price: 800
      },
      {
        id: 3,
        title: "Рыба с картошкой и салатом",
        imageId: "https://mykaleidoscope.ru/x/uploads/posts/2022-10/1666290029_37-mykaleidoscope-ru-p-ribnii-salat-s-kartofelem-krasivo-42.jpg",
        description: "Красная рыба, подающаяся с лимоном и летним салатом",
        price: 2000
      }
]