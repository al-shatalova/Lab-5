import React from "react";
import {Food} from "./Food";

export class FoodList extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            selectedCategory: "dishes",
            selectedSubcategory: "Салаты и закуски",
        };
    }

    handleCategoryChange(category) {
        this.setState({ selectedCategory: category });
        if (category === 'drinks') {
            this.setState({ selectedSubcategory: "Чай" });
        }
        if (category === 'dishes') {
            this.setState({ selectedSubcategory: "Салаты и закуски" });
        }
    }
    handleSubcategoryChange(subcategory) {
        console.log(subcategory)
        this.setState({ selectedSubcategory: subcategory });
    }
    render() {
        let subcategories;
            if (this.state.selectedCategory === "dishes") {
                subcategories = ["Салаты и закуски", "Супы", "Горячие блюда", "Десерты", "Детское меню", "Ещё"];
            } else {
                subcategories = ["Чай", "Кофе", "Ещё"];
        }

        return (
            <div className="container mt-4">
                <div className="d-flex">
                    <button
                        className={`nav-link btn btn-light ${this.state.selectedCategory === "dishes" ? "active" : ""}`}
                        onClick={() => this.handleCategoryChange("dishes")}>
                        Кухня
                    </button>

                    <button
                        className={`nav-link btn btn-light ${this.state.selectedCategory === "drinks" ? "active" : ""}`}
                        onClick={() => this.handleCategoryChange("drinks")}
                    >
                       Бар
                    </button>
                </div>
                <ul className="nav nav-tabs">
                    {subcategories.map((subcategory, index) => (
                        <li className="nav-item" key={index}>
                            <button
                                className={`nav-link ${this.state.selectedSubcategory === subcategory ? "active" : ""}`}
                                onClick={() => this.handleSubcategoryChange(subcategory)}
                            >
                                {subcategory}
                            </button>
                        </li>
                    ))}
                </ul>
                {this.state.selectedCategory === "dishes" ?
                    <div style={{"column-gap": "5rem"}} className="row mt-3">
                        {dishes.map((food, index) => {
                            if (this.state.selectedSubcategory === food.subcategory) {
                                return <div className="col-3 mb-4" key={index}>
                                    <Food
                                        name={food.name}
                                        desc={food.desc}
                                        image={food.image}
                                        price={food.price}
                                        weight={food.weight}
                                    />
                                </div>
                            }
                        })}
                    </div>
                    :
                    <div style={{"column-gap": "5rem"}} className="row mt-4">
                        {drinks.map((food, index) => {
                            if (this.state.selectedSubcategory === food.subcategory) {
                                return <div className="col-3 mb-4" key={index}>
                                    <Food
                                        name={food.name}
                                        desc={food.desc}
                                        image={food.image}
                                        price={food.price}
                                        weight={food.weight}
                                    />
                                </div>
                            }
                        })}
                    </div>
                }

            </div>
        );
    }
}

const dishes = [
    {
        name: "Цукини с брынзой",
        desc: "С соусом из маринованного лимона и кедровыми орехами.",
        image: "https://coffeemania.ru/uploads/p5205/22a8362eeaf8cba.jpg",
        price: 790,
        weight: 225,
        subcategory: 'Салаты и закуски',
    },
    {
        name: "Ростбиф из пиканьи",
        desc: "С маринованными огурцами и соусом тонкацу.",
        image: "https://coffeemania.ru/uploads/p5039/829a84db19b0903.jpg",
        price: 950,
        weight: 100,
        subcategory: 'Салаты и закуски',
    },
    {
        name: "Баклажан со страчателлой",
        desc: "Баклажан со страчателлой и томатным соусом.",
        image: "https://coffeemania.ru/uploads/p3391/ff31b405d1468a6.jpg",
        price: 950,
        weight: 230,
        subcategory: 'Салаты и закуски',
    },
    {
        name: "Бора-Бора",
        desc: "Микс из авокадо, хрустящих огурцов и тигровых креветок, приготовленных на гриле, с ароматным зелёным луком. Заправляется оливковым маслом, морской солью и винным уксусом.",
        image: "https://coffeemania.ru/uploads/p395/779d16e793fb1db.jpg",
        price: 970,
        weight: 190,
        subcategory: 'Салаты и закуски',
    },
    {
        name: "Мухаммара",
        desc: "С домашней лепёшкой с заатаром.",
        image: "https://coffeemania.ru/uploads/p4869/29a61750ffd8304.jpg",
        price: 770,
        weight: 180,
        subcategory: 'Салаты и закуски',
    },
    {
        name: "Шведский тост с лососем",
        desc: "Слабосолёный лосось, сливочный сыр с зеленью и чесноком, малосольные огурцы.",
        image: "https://coffeemania.ru/uploads/p616/5318bf0751ac0c8.jpg",
        price: 930,
        weight: 130,
        subcategory: 'Салаты и закуски',
    },
    {
        name: "Бессарабский крем-суп из тыквы",
        desc: "Готовится на курином бульоне с добавлением имбиря, лимонника и сливок. Подаётся с шапочкой взбитых кокосовых сливок, окроплённых крем-бальзамиком и обжаренными тыквенными семечками.",
        image: "https://coffeemania.ru/uploads/p1960/eadd920a503e89d.jpg",
        price: 690,
        weight: 300,
        subcategory: 'Супы',
    },
    {
        name: "Борщ",
        desc: "С говядиной, белой фасолью и зеленью. Подаётся со сметаной.",
        image: "https://coffeemania.ru/uploads/p1959/718901744b246b7.jpg",
        price: 730,
        weight: 400,
        subcategory: 'Супы',
    },
    {
        name: "Грибной суп",
        desc: "На бульоне из белых архангельских грибов с картофелем и пассерованными луком и морковью. Дополняется зеленью петрушки. Подаётся со сметаной.",
        image: "https://coffeemania.ru/uploads/p563/3597a0dba47ac54.jpg",
        price: 750,
        weight: 300,
        subcategory: 'Супы',
    },
    {
        name: "Домашняя лапша",
        desc: "Наваристый куриный суп с домашней лапшой, кусочками нежной курицы и пассеровкой из лука и моркови.",
        image: "https://coffeemania.ru/uploads/p563/3597a0dba47ac54.jpg",
        price: 750,
        weight: 350,
        subcategory: 'Супы',
    },
    {
        name: "Телячьи щёчки с лисичками",
        desc: "Гарнир на выбор: каша из злаков или картофельное пюре.",
        image: "https://coffeemania.ru/uploads/p5385/8845f119d058295.jpg",
        price: 1200,
        weight: 210,
        subcategory: 'Горячие блюда',
    },
    {
        name: "Шницель по-милански",
        desc: "Подаётся с салатом из руколы, сельдерея, яблок, томатов черри и соусом васаби и демиглас.",
        image: "https://coffeemania.ru/uploads/p1065/03fcde096554540.jpg",
        price: 1500,
        weight: 360,
        subcategory: 'Горячие блюда',
    },
    {
        name: "Цыплёнок с молодым картофелем",
        desc: "Лисичками и кабачками, с соусом из аджики и сметаной.",
        image: "https://coffeemania.ru/uploads/p2788/bbb0336b8019e46.jpg",
        price: 1300,
        weight: 300,
        subcategory: 'Горячие блюда',
    },
    {
        name: "Большая котлета из говядины",
        desc: "С брусничным соусом и картофельным пюре.",
        image: "https://coffeemania.ru/uploads/p2375/0e66c5c12dc4cd2.jpg",
        price: 1100,
        weight: 320,
        subcategory: 'Горячие блюда',
    },
    {
        name: "Котлета по-киевски",
        desc: "Из фермерского петуха породы хаббард с трюфельным маслом. Подаётся с картофельным пюре и салатом айсберг с соусом из сыра грюйер.",
        image: "https://coffeemania.ru/uploads/p2887/f5fe7e7e4afcb72.jpg",
        price: 1500,
        weight: 400,
        subcategory: 'Горячие блюда',
    },
    {
        name: "Курица с рисом и зелёным карри",
        desc: "Сочная курица в устричном соусе и азиатских специях. Обжаривается на гриле и подаётся на «подушке» из риса с соусом зелёный карри.",
        image: "https://coffeemania.ru/uploads/p522/aa14ea43391bc43.jpg",
        price: 1100,
        weight: 280,
        subcategory: 'Горячие блюда',
    },
    {
        name: "Бони Марони",
        desc: "Фисташковая тарталетка, миндальный крем с базиликом, малиновая начинка, крем с маскарпоне и свежие ягоды малины.",
        image: "https://coffeemania.ru/uploads/p5001/dd21fd6e06538e4.jpg",
        price: 750,
        weight: 100,
        subcategory: 'Десерты',
    },
    {
        name: "Фико",
        desc: "Веган-десерт без глютена с сочным инжиром и малиной, кокосовым кремом и кокосовым бисквитом с нотками лимона.",
        image: "https://coffeemania.ru/uploads/p3075/7010c4d3b6c2b56.jpg",
        price: 850,
        weight: 115,
        subcategory: 'Десерты',
    },
    {
        name: "Груша и солёная карамель",
        desc: "Слойка с миндальным кремом, грушей в солёной карамели и миндальными перьями.",
        image: "https://coffeemania.ru/uploads/p5270/6161b26349e77fd.jpg",
        price: 670,
        weight: 70,
        subcategory: 'Десерты',
    },
    {
        name: "Мёд и имбирь",
        desc: "Имбирный бисквит, медово-имбирный ганаш, конфитюр имбирь и шалфей и конфитюр мёд и имбирь.",
        image: "https://coffeemania.ru/uploads/p5272/4cd3a6a2b0c56ff.jpg",
        price: 650,
        weight: 70,
        subcategory: 'Десерты',
    },
    {
        name: "Шайла",
        desc: "Миндальный рулет, конфи апельсин и лимон, клубничное кули, ванильный крем и ягоды клубника.",
        image: "https://coffeemania.ru/uploads/p4807/1c5169e0cd418cc.jpg",
        price: 750,
        weight: 120,
        subcategory: 'Десерты',
    },
    {
        name: "Кето-чизкейк",
        desc: "Чемпион среди десертов для поклонников стиля питания «кето» и для всех ценителей чизкейков. Воздушный чизкейк на кето-бисквите с ягодной начинкой и свежими ягодами голубики, ежевики, клубники. Без глютена и сахара.",
        image: "https://coffeemania.ru/uploads/p2705/b74e23ee4a1eed8.jpg",
        price: 690,
        weight: 105,
        subcategory: 'Десерты',
    },
    {
        name: "Детские колбаски",
        desc: "Две ароматные колбаски из индейки собственного приготовления, обжаренные на гриле. Подаются с перепелиной яичницей и гарниром на выбор.",
        image: "https://coffeemania.ru/uploads/p467/eb0daddecacd15c.jpg",
        price: 470,
        weight: 125,
        subcategory: 'Детское меню',
    },
    {
        name: "Паста ракушки по–флотски",
        desc: "С рагу из телятины и сметаной.",
        image: "https://coffeemania.ru/uploads/p4344/0b5193bdcb4de75.jpg",
        price: 470,
        weight: 200,
        subcategory: 'Детское меню',
    },
    {
        name: "Мини-пельмени в бульоне",
        desc: "С говядиной и курицей.",
        image: "https://coffeemania.ru/uploads/p4055/90e9720d6e2612f.jpg",
        price: 550,
        weight: 250,
        subcategory: 'Детское меню',
    },
    {
        name: "Детская пожарская котлета",
        desc: "С картофельным пюре.",
        image: "https://coffeemania.ru/uploads/p4341/86a6213488b6222.jpg",
        price: 510,
        weight: 225,
        subcategory: 'Детское меню',
    },
    {
        name: "Куриные наггетсы-эскимо",
        desc: "С сырным соусом.",
        image: "https://coffeemania.ru/uploads/p4342/b0cee26017f1ee1.jpg",
        price: 450,
        weight: 100,
        subcategory: 'Детское меню',
    },
    {
        name: "Глория",
        desc: "Шоколадный крем, крем из карамельного шоколада и крем из банана с карамелью и шоколадный мусс с бананом.",
        image: "https://coffeemania.ru/uploads/p5273/ed9d4dfca52b878.jpg",
        price: 650,
        weight: 85,
        subcategory: 'Детское меню',
    },
    {
        name: "Боул с миксом зелёных салатов",
        desc: "",
        image: "https://coffeemania.ru/uploads/p5391/700a416df88f3a2.jpg",
        price: 550,
        weight: 70,
        subcategory: 'Ещё',
    },
    {
        name: "Овощи на гриле",
        desc: "Баклажаны, перец, цукини, запечённый томат.",
        image: "https://coffeemania.ru/uploads/p575/42b8f69280460ba.jpg",
        price: 590,
        weight: 200,
        subcategory: 'Ещё',
    },
    {
        name: "Японский рис",
        desc: "",
        image: "https://coffeemania.ru/uploads/p577/a5abc70e8681258.jpg",
        price: 450,
        weight: 150,
        subcategory: 'Ещё',
    },
    {
        name: "Гречка с луком",
        desc: "С поджаренным репчатым луком и петрушкой.",
        image: "https://coffeemania.ru/uploads/p578/eaef3ffcb594262.jpg",
        price: 390,
        weight: 150,
        subcategory: 'Ещё',
    },
    {
        name: "Шпинат",
        desc: "Обжаривается со сливками.",
        image: "https://coffeemania.ru/uploads/p581/53a3c36c2587d85.jpg",
        price: 550,
        weight: 135,
        subcategory: 'Ещё',
    },
    {
        name: "Брокколи на гриле",
        desc: "",
        image: "https://coffeemania.ru/uploads/p588/d01ab5d90367fd5.jpg",
        price: 550,
        weight: 120,
        subcategory: 'Ещё',
    }
];

const drinks = [
    {
        name: "Мятный чай",
        desc: "Чай из душистой свежей мяты.",
        image: "https://coffeemania.ru/uploads/p344/cfb25064cc344db.jpg",
        price: 620,
        weight: 500,
        subcategory: 'Чай',
    },
    {
        name: "Малиновый чай",
        desc: "Ароматный ягодный чай на основе малины, земляники и каркаде с сушёной вишней.",
        image: "https://coffeemania.ru/uploads/p346/e862ee1b9a74f50.jpg",
        price: 770,
        weight: 500,
        subcategory: 'Чай',
    },
    {
        name: "Имбирный",
        desc: "Имбирь, лемонграсс и мёд. Пряный, медовый, согревающий.",
        image: "https://coffeemania.ru/uploads/p345/727ea3d853682db.jpg",
        price: 740,
        weight: 500,
        subcategory: 'Чай',
    },
    {
        name: "Чай манго и маракуйя",
        desc: "С мякотью свежей маракуйи.",
        image: "https://coffeemania.ru/uploads/p348/7d770779a9f81a2.jpg",
        price: 770,
        weight: 500,
        subcategory: 'Чай',
    },
    {
        name: "Сбитень",
        desc: "Старинный русский напиток с пряно-медовым ягодным вкусом с большим количеством свежей мяты, добавлением лайма, лимона и щепоткой корицы.",
        image: "https://coffeemania.ru/uploads/p2016/a5285790c78b7cd.jpg",
        price: 690,
        weight: 500,
        subcategory: 'Чай',
    },
    {
        name: "Шиповник",
        desc: "Согревающий настой ягод шиповника с горным мёдом и долькой апельсина.",
        image: "https://coffeemania.ru/uploads/p762/0f0692a64146ab9.jpg",
        price: 690,
        weight: 500,
        subcategory: 'Чай',
    },
    {
        name: "Раф молочный",
        desc: "Готовится на коровьем молоке.\n" +
            "С этой чашкой кофе вы заботитесь о планете: мы компенсируем ее углеродный след.",
        image: "https://coffeemania.ru/uploads/p299/8b1d790d92ff700.jpg",
        price: 590,
        weight: 300,
        subcategory: 'Кофе',
    },
    {
        name: "Латте куркума",
        desc: "Пряный, полезный, веганский и отлично согревающий.\n" +
            "С этой чашкой кофе вы заботитесь о планете: мы компенсируем ее углеродный след.",
        image: "https://coffeemania.ru/uploads/p2540/7b095bb4a8a772b.jpg",
        price: 610,
        weight: 300,
        subcategory: 'Кофе',
    },
    {
        name: "Капучино",
        desc: "Напиток на основе эспрессо со вспененным молоком. Вкус капучино идеально сбалансирован.\n" +
            "С этой чашкой кофе вы заботитесь о планете: мы компенсируем ее углеродный след.",
        image: "https://coffeemania.ru/uploads/p2958/14468d4b1838f72.jpg",
        price: 410,
        weight: 200,
        subcategory: 'Кофе',
    },
    {
        name: "Какао",
        desc: "На основе бельгийского горячего шоколада и коровьего молока.",
        image: "https://coffeemania.ru/uploads/p337/1909988b16547f8.jpg",
        price: 620,
        weight: 300,
        subcategory: 'Кофе',
    },
    {
        name: "Раф мандарин",
        desc: "Воздушный цитрусовый напиток с церемониальной матчей на кокосовой основе.\n" +
            "С этой чашкой кофе вы заботитесь о планете: мы компенсируем ее углеродный след.",
        image: "https://coffeemania.ru/uploads/p2316/c0dc07e79666302.jpg",
        price: 610,
        weight: 300,
        subcategory: 'Кофе',
    },
    {
        name: "Раф Moss",
        desc: "Матча и кокосовая основа.\n" +
            "С этой чашкой кофе вы заботитесь о планете: мы компенсируем ее углеродный след.",
        image: "https://coffeemania.ru/uploads/p350/8e0c98a13770d9b.jpg",
        price: 610,
        weight: 300,
        subcategory: 'Кофе',
    },
    {
        name: "Минеральная вода Филетте (негазированная)",
        desc: "Вода удостоена высшей награды за вкус – три золотые звезды SUPERIOR TASTE AWARD 2019 от International Taste Institute.",
        image: "https://coffeemania.ru/uploads/p212/7b4c03e8d6f16d7.jpg",
        price: 610,
        weight: 375,
        subcategory: 'Ещё',
    },
    {
        name: "Coca-Cola Zero",
        desc: "",
        image: "https://coffeemania.ru/uploads/p5410/16d619888fa3e56.jpg",
        price: 320,
        weight: 330,
        subcategory: 'Ещё',
    },
    {
        name: "Безалкогольное игристое Blanc de Blancs",
        desc: "ODDBIRD – шведский бренд премиальных безалкогольных напитков. Для изготовления вина используется виноград сорта Шардоне, произрастающий на виноградниках апелласьона Лангедок-Руссийон. Сбор урожая проводится вручную. Деликатное удаление алкоголя методом вакуумной дистилляции, позволяющей сохранить ароматические и вкусовые компоненты вина. Выдержка до 12 месяцев.",
        image: "https://coffeemania.ru/uploads/p4386/dae4ca4a79de6fc.jpg",
        price: 1600,
        weight: 200,
        subcategory: 'Ещё',
    },
    {
        name: "Минеральная вода Филетте (газированная)",
        desc: "Вода удостоена высшей награды за вкус – три золотые звезды SUPERIOR TASTE AWARD 2019 от International Taste Institute.",
        image: "https://coffeemania.ru/uploads/p214/032938c0bf8ff50.jpg",
        price: 610,
        weight: 375,
        subcategory: 'Ещё',
    },
    {
        name: "Апельсиновый свежевыжатый сок",
        desc: "Можно заказать сок одного вида или микс.",
        image: "https://coffeemania.ru/uploads/p3532/7a3d9b62f8b483f.jpg",
        price: 430,
        weight: 175,
        subcategory: 'Ещё',
    },
    {
        name: "Яблочный свежевыжатый сок",
        desc: "Можно заказать сок одного вида или микс.",
        image: "https://coffeemania.ru/uploads/p3531/de9672ec1260444.jpg",
        price: 430,
        weight: 175,
        subcategory: 'Ещё',
    }
];