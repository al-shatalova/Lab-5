import logo from './logo.svg';
import './App.css';
import React from "react";
import {Header} from "./Header";
import {SpecialOffer} from "./SpecialOffer";
import {Menu} from "./Menu";
import {Advertisement} from "./Advertisement";
import {Footer} from "./Footer";

function App() {
  return (
      <div>
        <Header />
        <SpecialOffer />
        <Menu />
        <Advertisement />
        <Footer />
      </div>
  );
}

export default App;
