import React from "react";
import {FoodList} from "./FoodList";
export class Menu extends React.Component {
    render() {
        return (
            <div>
                <h1>
                    <span style={{ marginLeft: "40px" }}>Меню</span>
                </h1>
                <FoodList />
                <div className="text-center">
                    <button className='btn btn-light' style={{width:"200px",  margin: "30px",  borderRadius: '20px', border: '2px solid #343a40',}}>Ещё</button>
                </div>
            </div>
        );
    }
}
