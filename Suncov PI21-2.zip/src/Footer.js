import React from "react";

export function Footer() {
    return (
        <footer className="text-center mt-4">
            <p>&copy; {new Date().getFullYear()} Кофемания, Сунцов Андрей</p>
        </footer>
    );
}
