import React from "react";
import {Food} from "./Food";

export const Advertisement = () => {

    const dishes = [
    {
        name: "Бриошь с брискетом",
        desc: "С горчично-медовым соусом.",
        image: "https://coffeemania.ru/uploads/p5393/4ac1369aff6d1ac.jpg",
        price: 950,
        weight: 130,
    },

    {
        name: "Пшённая каша с тыквой",
        desc: "С карамелизированной тыквой и душистой корицей. Готовится на молоке без сахара.",
        image: "https://coffeemania.ru/uploads/p547/c9d86267258e426.jpg",
        price: 550,
        weight: 250,
    },

    {
        name: "Каламарата с аргентинскими креветками",
        desc: "С помидорами и маслом юдзу.",
        image: "https://coffeemania.ru/uploads/p5390/8bb64d9ff778390.jpg",
        price: 1300,
        weight: 320,
    }
    ]

    const imageStyle = {
        width: "250px", // Укажите размер, который вам подходит
        height: "250px", // Укажите размер, который вам подходит
    };

    return (
        <div className="jumbotron d-flex align-items-center">
            <div style={{ flex: 1 }}>
                <h1>Сезонные новинки</h1>
                <h3>Золотая пора: осенние новинки в меню</h3>
                <h5>Идеально начать день можно с уже знакомой многим пшённой каши с тыквой, а также сытной осенней новинки: каши из четырёх злаков с яйцом пашот, белыми грибами и сыром. Тем, кто предпочитает лёгкий завтрак, наверняка придутся по вкусу цельнозерновые хлебцы с творогом и авокадо.
                    <br/>

                    <br/>Сезонные блюда можно будет попробовать с 10 октября во всех московских ресторанах, а также заказать на сайте и в приложении «Кофемания».</h5>
            </div>
            <div style={{ flex: 2 }}>
                <div className="d-flex">
                    {dishes.map((food, index) => (
                        <div className="col-4" key={index}>
                            <Food
                                name={food.name}
                                desc={food.desc}
                                image={food.image}
                                price={food.price}
                                oldPrice={food.oldPrice}
                                size={300}
                            />
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};
