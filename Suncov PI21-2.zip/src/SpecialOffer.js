import React from "react";

export const SpecialOffer = () => {
    return (
        <div className="alert alert-warning d-flex justify-content-between align-items-center" role="alert">
            <div>Специальное предложение: Получите скидку 20% на заказ от 1 500₽ до конца месяца при подписке на новостную рассылку!</div>
            <div className="d-flex">
                <input type="email" placeholder="Введите ваш email" className="form-control mr-2" />
                <button className="btn btn-dark">Подписаться</button>
            </div>
        </div>
    );
};