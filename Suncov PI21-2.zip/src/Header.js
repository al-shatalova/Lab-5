import React from "react";

export function Header() {
    const navStyle = {
        marginLeft: "50px",
    };

    const linkStyle = {
        color: "black",
        margin: "0 20px",
        textDecoration: "none",
        fontSize: "18px",
    };

    const brandStyle = {
        color: "#343a40",
        fontWeight: "bold",
        fontSize: "24px",
        marginRight: "20px",
    };

    const accountIconStyle = {
        color: "#343a40",
        fontSize: "28px",
    };



    return (
        <header>
            <nav className="navbar navbar-expand-lg navbar-light">

                <img src="https://coffeemania.ru/img/navmenu/coffeemania-logo.svg" alt={'Кофемания'} style={{padding: "10px"}}/>

                <h1 className="navbar-brand" style={brandStyle}>
                    Кофемания
                </h1>

                <div className="collapse navbar-collapse" id="navbarNav" style={navStyle}>
                    <ul className="navbar-nav">
                        <li className="nav-item">
                            <a href="#" style={linkStyle}>
                                Меню
                            </a>
                        </li>
                        <li className="nav-item">
                            <a href="#" style={linkStyle}>
                                Программа лояльности
                            </a>
                        </li>
                        <li className="nav-item">
                            <a href="#" style={linkStyle}>
                                Новости
                            </a>
                        </li>
                        <li className="nav-item">
                            <a href="#" style={linkStyle}>
                                Контакты
                            </a>
                        </li>
                        <li className="nav-item">
                            <a href="#" style={linkStyle}>
                                Прочее
                            </a>
                        </li>
                    </ul>
                    <div style={accountIconStyle}>
                        <a href="#">
                            <i className="fas fa-user"></i>
                        </a>
                    </div>
                </div>
            </nav>
        </header>
    );
}
