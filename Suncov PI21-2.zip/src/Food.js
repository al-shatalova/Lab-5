import React from "react";

export class Food extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            liked: false,
        };
    }
    render() {
        const { name, desc, image, price, weight, size = 350 } = this.props;


        const foodStyle = {
            width: `${size}px`,
            height: `${size * 1.5}px`,
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
            alignItems: "center",
            border: '2px solid black',

        };
        const imageStyle = {
            width: `100%`,
            "object-fit": 'contain',
            // height: `${size - 50}px`,
            padding: "10px",
        };

        return (
            <div className="card" style={foodStyle}>
                <img src={image} className="card-img-top" alt={name} style={imageStyle} />
                <div className="card-body d-flex flex-column align-items-center" style={{justifyContent: "space-between", textAlign: "center"}}>
                    <h5 className="card-title">{name}</h5>
                    <p  className="card-text" style={{overflow: "auto", textAlign: "center", padding: "0px 10px"}}>{desc}</p>
                    <div className="d-flex justify-content-between align-items-center">
                        <span className="card-text" style={{ display: "inline-block", marginRight: "10px", fontWeight: 'lighter' }}>Цена: {price}₽,   </span>
                        {weight ? (
                            <span className="card-text" style={{ display: "inline-block", fontWeight: 'lighter'}}>
      {weight}г
    </span>
                        ) : null}
                    </div>
                    <div className="d-flex justify-content-between align-items-center">
                        <button className="btn btn-dark">Добавить в корзину</button>

                        <button style={{
                            background: 'none',
                            border: 'none',
                            fontSize: '19px',
                            padding: '10px',
                            cursor: 'pointer',
                        }}
                                onClick={() => {
                                    this.setState({liked: !this.state.liked})
                                }}
                        >
                            {this.state.liked
                            ? <span role="img" aria-label="Добавить в избранное">❤️</span>
                            : <span role="img" aria-label="Добавить в избранное">🖤</span>
                            }
                        </button>

                    </div>
                </div>
            </div>
        );
    }
}
