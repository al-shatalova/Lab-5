import logo from './logo.svg';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import React, { useState } from 'react';

function Avatar({ person, size = 350 }) {
  const [isMenuShown, setIsMenuShown] = useState(false);
  const toggleMenu = () => {
      setIsMenuShown(current => !current);
  };

  return (
      <div className="avatar-container">
          <img
              className="avatar"
              src={person.imageId}
              alt={person.name}
              width={size}
              height={size - 80}
          />
          <p className="avatar-name">{person.name}</p>
          <button onClick={toggleMenu}>Подробнее</button>
          {isMenuShown && (
                <div className="additional-menu">
                    <Box price={person.price} />
                </div>
            )}
        </div>
    );
}
function Box({ price }) {
    return (
        <div className="box-menu">
            <p>Цена: {price} рублей</p>
        </div>
    );
}


function App() {
    return (
                    <div>
                        <nav className="navbar navbar-expand-lg navbar-light bg-light navbar1">
              <button
                className="navbar-toggler"
                type="button"
                data-toggle="collapse"
                data-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent"
                aria-expanded="false"
                aria-label="Toggle navigation"
              >
                <span className="navbar-toggler-icon"></span>
              </button>

              <div className="collapse navbar-collapse" id="navbarSupportedContent">
                <ul className="navbar-nav mr-auto">
                  <li className="nav-item active">
                    <a className="nav-link" href="#">
                      Sweet dream <span className="sr-only"></span>
                    </a>
                  </li>
                  <li className="nav-item">
                    <a className="nav-link" href="#">
                      Меню
                    </a>
                  </li>
                  <li className="nav-item">
                    <a className="nav-link" href="#">
                      о нас
                    </a>
                  </li>
                  <li className="nav-item">
                    <a className="nav-link" href="#">
                      Отзывы посетителей
                    </a>
                  </li>
                </ul>
                <form className="form-inline ml-auto">
                  <input
                    className="form-control mr-sm-2"
                    type="search"
                    placeholder="Найди свой десерт"
                    aria-label="Поиск"
                  />
                  <button className="btn btn-outline-success my-2 my-sm-0" type="submit">
                    Поиск
                  </button>
                </form>
              </div>
            </nav>


            
            <h1>Топ-10 десертов от шеф повара</h1>
            <div className="avatar-row">
                <Avatar
                    person={{
                        name: 'Торт Москва',
                        imageId:
                            'https://dobryninsky.ru/upload/iblock/32a/32a1a1ae2634dee51744459b5d362d3e.jpg',
                        price: '2100'
                    }}
                />
                <Avatar
                    person={{
                        name: 'Фисташковый рулет',
                        imageId:
                            'https://sdelaemvkusno.ru/wp-content/uploads/2022/10/merengovyj-rulet-fistashki-malina-1.jpg',
                            price: '550'
                    }}
                />
                <Avatar
                    person={{
                        name: 'Красный бархат',
                        imageId:
                            'http://foodnorma.ru/media/k2/items/cache/576492c356d8e0278dfa7b752bad5bc8_XL.jpg',
                            price: '600'
                    }}
                />
                <Avatar
                    person={{
                        name: 'Осенние блинчики',
                        imageId:
                            'http://klublady.ru/uploads/posts/2022-02/1645041080_19-klublady-ru-p-blini-s-yagodami-foto-21.jpg',
                            price: '400'
                    }}
                />
                <Avatar
                    person={{
                        name: 'Десерт Анна Павлова',
                        imageId:
                            'https://mykaleidoscope.ru/uploads/posts/2020-01/1579915213_4-p-desert-anni-pavlovoi-7.jpg',
                            price: '750'
                    }}
                />
            </div>
        </div>
    );
}

export default App;