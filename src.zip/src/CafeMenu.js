// RestaurantMenu.js
import React, { useState } from "react";
import { Modal, Button } from "react-bootstrap";
import "./CafeMenu.css";

function CafeMenu({ menuItems }) {
  const [showModal, setShowModal] = useState(false);
  const [selectedItem, setSelectedItem] = useState(null);

  const openModal = (item) => {
    setSelectedItem(item);
    setShowModal(true);
  };

  const closeModal = () => {
    setSelectedItem(null);
    setShowModal(false);
  };

  return (
    <div className="menu">
      <h1>Меню ресторана</h1>
      <div className="container-fluid">
        <div className="row">
          {menuItems.map((item) => (
            <div key={item.id} className="col-md-2 menu-card">
              <div className="menu-card-inner">
                <img
                  src={item.image}
                  alt={item.name}
                  onClick={() => openModal(item)}
                />
                <h2>{item.name}</h2>
                <p>Цена: {item.price} руб.</p>
                <p>Ингредиенты: {item.ingredients}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      <Modal show={showModal} onHide={closeModal}>
        <Modal.Header closeButton>
          <Modal.Title>{selectedItem?.name}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <img
            src={selectedItem?.image}
            alt={selectedItem?.name}
            style={{ maxWidth: "100%", maxHeight: "400px" }}
          />
          <p>Цена: {selectedItem?.price} руб.</p>
          <p>Ингредиенты: {selectedItem?.ingredients}</p>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={closeModal}>
            Закрыть
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
}

export default CafeMenu;
