import React from "react";
import Navbar from './Navbar';
import CafeMenu from "./CafeMenu";
import menuItems from "./menuData";

function App() {
  return (
    <div>
      <Navbar />
      <CafeMenu menuItems={menuItems} />
    </div>
  );
}

export default App;
