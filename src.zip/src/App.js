import React, {useState} from 'react';
import './App.css';

function App() {
    const menuItems = [
        {
            id: 1,
            name: 'Борщ вегетарианский',
            type: 'первое',
            price: 300,
            ingredients: 'Свекла, картофель, морковь, капуста, лук, чеснок, томатная паста, соль, перец, зелень, сметана',
            image: 'https://www.gastronom.ru/binfiles/images/20150121/bb390759.jpg',
        },
        {
            id: 2,
            name: 'Солянка',
            type: 'первое',
            price: 270,
            ingredients: 'Солянка - это суп из разных видов мяса, колбасы, огурцов, каперсов, маслин, лимона и сметаны.',
            image: "https://www.gastronom.ru/binfiles/images/20210112/bd78f063.jpg",
        },
        {
            id: 3,
            name: 'Грибной крем-суп',
            type: 'первое',
            price: 280,
            ingredients: 'Грибной крем-суп - это нежный суп из свежих грибов, сливок, лука, чеснока и трав. Подается с гренками.',
            image: 'https://i.ytimg.com/vi/EtzNcVSlFRo/maxresdefault.jpg',
        },
        {
            id: 4,
            name: 'Уха',
            type: 'первое',
            price: 300,
            ingredients: 'Уха - это рыбный суп с картофелем, морковью, луком, лавровым листом и перцем. Подается с укропом и сметаной.',
            image: 'https://s1.eda.ru/StaticContent/Photos/120304025019/130221235813/p_O.jpg',
        },
        {
            id: 5,
            name: 'Бефстроганов',
            type: 'второе',
            price: 450,
            ingredients: 'Говядина, лук, грибы, сметана, мука, масло, соль, перец, петрушка, макароны',
            image: 'https://img1.russianfood.com/dycontent/images_upl/481/big_480247.jpg',
        },
        {
            id: 6,
            name: 'Брускетта с запеченным баклажаном',
            type: 'второе',
            price: 350,
            ingredients: 'Багет, баклажан, помидоры, чеснок, базилик, оливковое масло, соль, перец',
            image: 'https://italians-ekb.ru/upload/resize_cache/iblock/b5b/450_450_1d7a58ff99b324185ccb5ad5dfbdb5e85/ieemjhq83wtkb9971khpcfoxuitpbqw3.png',
        },
        {
            id: 7,
            name: "Эстонский картофельный салат",
            type: 'салаты',
            price: 250,
            ingredients: "Картофель, морковь, горошек, яйца, майонез, соль, перец",
            image: "https://avatars.dzeninfra.ru/get-zen_doc/3397162/pub_624d3d253f746179ade8a2cb_624d3d2c3f746179ade8aaf7/scale_1200",
        },
        {
            id: 8,
            name: "Свиные ребрышки в пиве",
            type: 'второе',
            price: 500,
            ingredients: "Свиные ребрышки, пиво, соевый соус, мед, чеснок, соль, перец, картофель, розмарин",
            image: "https://cs8.pikabu.ru/post_img/2016/09/10/5/1473489486143890491.jpg",
        },

        {
            id: 9,
            name: "Куриное карри",
            type: "второе",
            price: 400,
            ingredients: "Куриное филе, кокосовое молоко, лук, чеснок, имбирь, карри, куркума, соль, перец, рис",
            image: "https://img.povar.ru/main/1f/72/d2/6f/kurica_v_karri-420114.png",
        },
        {
            id: 10,
            name: "Лосось с овощами",
            type: 'второе',
            price: 500,
            ingredients: "Лосось, брокколи, морковь, цуккини, лимон, сливочное масло, соль, перец, укроп",
            image: "https://www.maggi.ru/data/images/recept/img564x436/recept_4820_yfui.jpg",
        },
        {
            id: 11,
            name: "Цезарь",
            type: 'салаты',
            price: 350,
            ingredients: "Салат романо, куриное филе, сыр пармезан, хлебные гренки, соус цезарь",
            image: "https://static.1000.menu/res/640/img/content-v2/eb/79/19516/salat-cezar-klassicheskii-s-kuricei_1611309331_16_max.jpg",
        },
        {
            id: 12,
            name: "Греческий",
            type: 'салаты',
            price: 300,
            ingredients: "Помидоры, огурцы, перец, лук, маслины, сыр фета, оливковое масло, орегано, соль",
            image: "https://img1.russianfood.com/dycontent/images_upl/557/big_556060.jpg",
        },



    ];

    const [selectedCategory, setSelectedCategory] = useState(null);

    const [showIngredients, setShowIngredients] = useState({});

    const toggleIngredients = (itemId) => {
        const newShowIngredients = {...showIngredients};
        newShowIngredients[itemId] = !newShowIngredients[itemId];
        setShowIngredients(newShowIngredients);
    };

    return (
        <div className="App">
            <header className="header">
                <h1>Ресторан на Перовской</h1>
                <p>Доставка: +7 (495) 345-06-45</p>
            </header>

            <nav className="menu">
                <ul>
                    <li onClick={() => setSelectedCategory('салаты')}>Салаты</li>
                    <li onClick={() => setSelectedCategory('первое')}>Первые блюда</li>
                    <li onClick={() => setSelectedCategory('второе')}>Второе</li>
                </ul>
            </nav>
            <div className="content">
                {selectedCategory ? (
                    <div>
                        <h2>{selectedCategory}</h2>
                        <ul className="menu-items">
                            {menuItems
                                .filter((item) => item.type === selectedCategory)
                                .map((item) => (
                                    <div key={item.id} className="menu-item">
                                        <img src={item.image} alt={item.name}/>
                                        <h3>{item.name}</h3>
                                        <p>Цена: {item.price} руб.</p>
                                        <button onClick={() => toggleIngredients(item.id)}>
                                            {showIngredients[item.id] ? 'Скрыть описание' : 'Показать описание'}
                                        </button>
                                        {showIngredients[item.id] && (
                                            <p>Описание: {item.ingredients}</p>
                                        )}
                                    </div>
                                ))}
                        </ul>
                    </div>
                ) : (
                    <div>
                        <h2>Вcё Меню</h2>
                        <ul className="menu-items">
                            {menuItems.map((item) => (
                                <div key={item.id} className="menu-item">
                                    <img src={item.image} alt={item.name}/>
                                    <h3>{item.name}</h3>
                                    <p>Цена: {item.price} руб.</p>
                                    <button onClick={() => toggleIngredients(item.id)}>
                                        {showIngredients[item.id] ? 'Скрыть описание' : 'Показать описание'}
                                    </button>
                                    {showIngredients[item.id] && (
                                        <p>Ингредиенты: {item.ingredients}</p>
                                    )}
                                </div>
                            ))}
                        </ul>
                    </div>
                )}
            </div>
            <div className="footer">
                <p>© 2023 Ресторан на Перовской. Все права защищены.</p>
            </div>
        </div>
    );
}
export default App;