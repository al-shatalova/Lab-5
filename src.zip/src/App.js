import React, { useState } from 'react';
import './App.css';

const menuItems = [
    { id: 1, name: 'Сырники', price : ['100р'], image: '1.png', ingredients: ['Творог', 'Яйца'] },
    { id: 2, name: 'Омлет', image: '2.png', price : ['100р'], ingredients: ['Яйца', 'Сыр', 'Томат'] },
    { id: 3, name: 'Английский Завтрак', price : ['100р'], image: '3.png', ingredients: ['Колбаски', 'Глазунья', 'Фасоль'] },
    { id: 4, name: 'Паста Карбонара', price : ['100р'], image: '4.png', ingredients: ['Бекон', 'Соус сливочный', 'Грибы', 'Сыр'] },
    { id: 5, name: 'Борщ', price : ['100р'], image: '5.png', ingredients: ['Говядина', 'Свекла', 'Картофель', 'Морковь', 'Лук'] },
    { id: 6, name: 'Салат Цезарь', price : ['100р'], image: '6.png', ingredients: ['Куриная грудка', 'Салат', 'Крутоны', 'Пармезан' ]},
];


function Navig(){
    return(<div>
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <a className="navbar-brand" href="#">Ресторан</a>
            <div className="collapse navbar-collapse" id="navbarText">
                <ul className="navbar-nav mr-auto" >
                    <li className="nav-item active">
                        <a className="nav-link" href="#">Меню<span className="sr-only">(current)</span></a>
                    </li>
                    <li className="nav-item">
                        <a className="nav-link" href="#">Акции</a>
                    </li>
                    <li className="nav-item">
                        <a className="nav-link" href="#">Адреса</a>
                    </li>
                    <li className="nav-item">
                        <a className="nav-link" href="#">Бонусы</a>
                    </li>
                    <li className="nav-item">
                        <a className="nav-link" href="#">Доставка</a>
                    </li>
                    <li className="nav-item">
                        <a className="nav-link" href="#">О компании</a>
                    </li>
                </ul>
            </div>
        </nav>
    </div>);
}

function App() {
    const [selectedMenuItem, setSelectedMenuItem] = useState(null);

    const handleMenuItemClick = (id) => {
        setSelectedMenuItem(id);
    };

    return (
        <div>
            <Navig/>
            <div className="menu-list">
                {menuItems.map((item) => (
                    <div key={item.id} className={`menu-item ${item.id === selectedMenuItem ? 'active' : ''}`}
                           onClick={() => handleMenuItemClick(item.id)}>
                        <img src={item.image}/>
                        <h3>{item.name}</h3>
                        <h5>{item.price}</h5>
                        {selectedMenuItem === item.id && (
                            <ul>
                                Состав:
                                {item.ingredients.map((ingredient, index) => (
                                    <li key={index}>{ingredient}</li>
                                ))}
                            </ul>
                        )}
                    </div>
                ))}
            </div>
        </div>
    );
}

export default App;

