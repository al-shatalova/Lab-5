import './App.css';

import React, {useState} from 'react';

const App = () => {
  const [dishes, setDishes] = useState([
    { id: 1, name: 'Борщ', price: 100, ingredients: 'Рёбра свиные, вода, свёкла, вода', image: 'https://img.delo-vcusa.ru/2020/11/Borshh-s-yablokami.jpg' },
    { id: 2, name: 'Блины', price: 150, ingredients: 'Яйца, простокваша, кипяток, масло', image: 'https://img.delo-vcusa.ru/2016/01/Nesladkie-bliny-s-rzhanoy-mukoy-1-230x150.jpg' },
    { id: 3, name: 'Жареная скумбрия', price: 200, ingredients: 'Скумбрия, мука, соль, масло', image: 'https://img.delo-vcusa.ru/2018/05/Zharenaja-skumbria-230x150.jpg' },
    { id: 4, name: 'Греческий салат', price: 200, ingredients: 'Сыр фета, болгарский перец, помидоры, огурец', image: 'https://img.delo-vcusa.ru/2014/02/grecheskij-salat-230x150.jpg' },
    { id: 5, name: 'Драники', price: 200, ingredients: 'Картошка, лук, яйцо, мука', image: 'https://img.delo-vcusa.ru/2013/04/DSC_0399-230x150.jpg' },
    { id: 6, name: 'Аппельсиновый кекс', price: 200, ingredients: 'Яйца, масло, мука, аппельсин', image: 'https://img.delo-vcusa.ru/2017/10/Apelsinovyy-keks-s-propitkoy-230x150.jpg' },
  ]);

  const [selectedDishId, setSelectedDishId] = useState(null);

  const handleDishClick = (dishId) => {
      setSelectedDishId((prevId) => (prevId === dishId ? null : dishId));
  };

  return (
      <div className='flex-container'>
        <h1>Меню ресторана</h1>
        <ul className='list-group'>
          {dishes.map((dish) => (
              <li className='list-group-item' key={dish.id} onClick={() => handleDishClick(dish.id)}>
                  <div>
                      <h2>
                          {dish.name}
                      </h2>
                      <img src={dish.image} alt={dish.name} width={250} height={250} />
                  </div>
                  {selectedDishId === dish.id && (
                      <li>
                          {/*<h2>{dishes.find((dish) => dish.id === selectedDishId).name}</h2>*/}
                          <p>Цена: {dishes.find((dish) => dish.id === selectedDishId).price}</p>
                          <p>Ингредиенты: {dishes.find((dish) => dish.id === selectedDishId).ingredients}</p>
                      </li>
                  )}
              </li>
          ))}
        </ul>
      </div>
  );
};

export default App;
