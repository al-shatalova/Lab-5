const menuItems = [
    {
      id: 1,
      name: "Борщ",
      price: 250,
      ingredients: "Свекла, капуста, мясо, лук, морковь",
      image: "https://new-magazine.ru/wp-content/uploads/2020/04/i-2.jpg",
    },
    {
      id: 2,
      name: "Пельмени",
      price: 180,
      ingredients: "Мясо, тесто",
      image: "https://sun9-64.userapi.com/KS02reQRL4yrZatDgotX2uEEZvofJd_M1H5y6Q/LO5ZvmxBLbQ.jpg",
    },
    {
        id: 2,
        name: "Пельмени",
        price: 180,
        ingredients: "Мясо, тесто",
        image: "https://sun9-64.userapi.com/KS02reQRL4yrZatDgotX2uEEZvofJd_M1H5y6Q/LO5ZvmxBLbQ.jpg",
    },
    {
        id: 2,
        name: "Пельмени",
        price: 180,
        ingredients: "Мясо, тесто",
        image: "https://sun9-64.userapi.com/KS02reQRL4yrZatDgotX2uEEZvofJd_M1H5y6Q/LO5ZvmxBLbQ.jpg",
    },
    {
        id: 2,
        name: "Пельмени",
        price: 180,
        ingredients: "Мясо, тесто",
        image: "https://sun9-64.userapi.com/KS02reQRL4yrZatDgotX2uEEZvofJd_M1H5y6Q/LO5ZvmxBLbQ.jpg",
    },
    {
        id: 2,
        name: "Пельмени",
        price: 180,
        ingredients: "Мясо, тесто",
        image: "https://sun9-64.userapi.com/KS02reQRL4yrZatDgotX2uEEZvofJd_M1H5y6Q/LO5ZvmxBLbQ.jpg",
    },
    {
        id: 2,
        name: "Пельмени",
        price: 180,
        ingredients: "Мясо, тесто",
        image: "https://sun9-64.userapi.com/KS02reQRL4yrZatDgotX2uEEZvofJd_M1H5y6Q/LO5ZvmxBLbQ.jpg",
    },
    {
        id: 2,
        name: "Пельмени",
        price: 180,
        ingredients: "Мясо, тесто",
        image: "https://sun9-64.userapi.com/KS02reQRL4yrZatDgotX2uEEZvofJd_M1H5y6Q/LO5ZvmxBLbQ.jpg",
    }
  ];

  export default menuItems;
